@echo off
REM ===================================================================
REM  JPOS - Pemasang Pembaruan
REM
REM  Script ini TIDAK PERNAH menyentuh folder database\ maupun
REM  storage\app\. Data penjualan, gambar produk, dan pengaturan toko
REM  Anda tetap utuh.
REM ===================================================================
setlocal
cd /d "%~dp0"

echo.
echo  ==========================================
echo    Pembaruan JPOS versi 2.15.3
echo  ==========================================
echo.

if not exist "JPOS.exe" (
    echo  GAGAL: Letakkan folder ini di dalam folder JPOS Anda,
    echo         lalu jalankan lagi UPDATE.bat dari sana.
    echo.
    pause
    exit /b 1
)

echo  [1/4] Menutup JPOS yang sedang berjalan...
taskkill /IM JPOS.exe /F >nul 2>&1
taskkill /IM php.exe /F >nul 2>&1
ping -n 3 127.0.0.1 >nul

echo  [2/4] Membuat cadangan database...
php\php.exe artisan jpos:backup --prefix=pre-update
if errorlevel 1 (
    echo.
    echo  GAGAL membuat cadangan database. Pembaruan DIBATALKAN.
    echo  Tidak ada satu pun berkas yang diubah.
    echo.
    pause
    exit /b 1
)

echo  [3/4] Memasang berkas baru...
robocopy "_baru" "." /E /NFL /NDL /NJH /NJS /NC /NS /NP >nul
if errorlevel 8 (
    echo.
    echo  GAGAL menyalin berkas. Cadangan database Anda ada di
    echo  storage\app\private\backups
    echo.
    pause
    exit /b 1
)

echo  [4/4] Menyiapkan database dan cache...
php\php.exe artisan jpos:prepare
if errorlevel 1 (
    echo.
    echo  Persiapan gagal. Periksa storage\logs\launcher.log
    echo.
    pause
    exit /b 1
)

echo.
echo  Pembaruan selesai. Menjalankan JPOS...
start "" "JPOS.exe"
ping -n 3 127.0.0.1 >nul
endlocal
