<?php

namespace App\Http\Controllers;

use App\Models\CashierShift;
use App\Models\CashTransaction;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\SalePayment;
use App\Models\User;
use App\Support\Akuntansi;
use App\Support\Angka;
use App\Support\EksporLaporan;
use App\Support\Laporan;
use App\Support\MetodeBayar;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * Satu pintu ekspor untuk sepuluh laporan.
 *
 * Ditulis terpusat, bukan sepuluh method ekspor yang disalin ke ReportController: kop toko,
 * nomor halaman, format rupiah, dan catatan asumsi harus persis sama di semua laporan, dan
 * kalau tiap laporan menyusunnya sendiri, cepat atau lambat salah satunya tertinggal.
 *
 * Tiap laporan hanya menyusun ISINYA - judul, kolom, baris, ringkasan, catatan. Cara
 * menjadikannya PDF atau Excel bukan urusan di sini.
 */
class LaporanEksporController extends Controller
{
    public function __invoke(Request $request, string $jenis, string $format, EksporLaporan $ekspor)
    {
        abort_unless(in_array($format, ['pdf', 'xlsx'], true), 404);

        $penyusun = 'laporan' . str_replace(' ', '', ucwords(str_replace('-', ' ', $jenis)));

        abort_unless(method_exists($this, $penyusun), 404);

        $laporan = $this->{$penyusun}($request)->pencetak($request->user()->name);

        return $format === 'pdf' ? $ekspor->pdf($laporan) : $ekspor->excel($laporan);
    }

    /** @return array{0:string,1:string} tanggal awal & akhir, default bulan berjalan */
    private function rentang(Request $request): array
    {
        return [
            $request->from ?: now()->startOfMonth()->toDateString(),
            $request->to ?: now()->toDateString(),
        ];
    }

    private const CATATAN_HPP = 'HPP dihitung dari harga modal yang berlaku saat barang itu terjual, bukan harga modal terkini. Laporan periode lampau karena itu bisa dicetak ulang dengan angka yang sama.';
    private const CATATAN_PAJAK = 'Omset TIDAK termasuk pajak yang dipungut dari pembeli. Pajak itu titipan yang harus disetorkan, bukan pendapatan toko.';
    private const CATATAN_RETUR = 'Retur mengurangi omset dan HPP, dicatat pada tanggal returnya - bukan mundur ke tanggal penjualan.';
    private const CATATAN_MODAL = 'Setoran modal pemilik dan uang yang diambil untuk keperluan pribadi (prive) TIDAK termasuk di sini. Keduanya memindahkan uang antara pemilik dan tokonya, bukan hasil berdagang; tempatnya di Neraca.';

    /* ==================================================================== LABA RUGI */

    private function laporanLabaRugi(Request $request): Laporan
    {
        [$dari, $sampai] = $this->rentang($request);

        $harian = Akuntansi::labaRugiHarian($dari, $sampai);
        $ringkas = Akuntansi::ringkasanLabaRugi($dari, $sampai);
        $pajak = Akuntansi::pajakDipungut($dari, $sampai);

        return Laporan::buat('Laporan Laba Rugi', 'laba-rugi')
            ->periode($dari, $sampai)
            ->ringkasan([
                'Omset Bersih' => Laporan::format($ringkas->omset, 'rupiah'),
                'Harga Pokok Penjualan' => Laporan::format($ringkas->hpp, 'rupiah'),
                'Laba Kotor' => Laporan::format($ringkas->laba_kotor, 'rupiah'),
                'Pendapatan Lain' => Laporan::format($ringkas->pendapatan_lain, 'rupiah'),
                'Beban Operasional' => Laporan::format($ringkas->beban, 'rupiah'),
                'LABA BERSIH' => Laporan::format($ringkas->laba_bersih, 'rupiah'),
                'Pajak dipungut (titipan)' => Laporan::format($pajak, 'rupiah'),
            ])
            ->bagian('Rincian Harian', [
                ['label' => 'Tanggal', 'key' => 'tanggal', 'format' => 'tanggal', 'lebar' => 14],
                ['label' => 'Omset Bersih', 'key' => 'omset', 'format' => 'rupiah'],
                ['label' => 'HPP', 'key' => 'hpp', 'format' => 'rupiah'],
                ['label' => 'Laba Kotor', 'key' => 'laba_kotor', 'format' => 'rupiah'],
                ['label' => 'Pendapatan Lain', 'key' => 'pendapatan_lain', 'format' => 'rupiah'],
                ['label' => 'Beban', 'key' => 'beban', 'format' => 'rupiah'],
                ['label' => 'Laba Bersih', 'key' => 'laba_bersih', 'format' => 'rupiah'],
            ], $harian->map(fn ($b) => (array) $b)->all(), [
                'tanggal' => 'TOTAL',
                'omset' => $ringkas->omset,
                'hpp' => $ringkas->hpp,
                'laba_kotor' => $ringkas->laba_kotor,
                'pendapatan_lain' => $ringkas->pendapatan_lain,
                'beban' => $ringkas->beban,
                'laba_bersih' => $ringkas->laba_bersih,
            ])
            ->catatan(self::CATATAN_PAJAK, self::CATATAN_HPP, self::CATATAN_RETUR, self::CATATAN_MODAL);
    }

    /* ======================================================================= NERACA */

    private function laporanNeraca(Request $request): Laporan
    {
        $tanggal = $request->tanggal ?: now()->toDateString();
        $p = Akuntansi::posisiPada($tanggal);

        $pos = fn (string $nama, float $nilai) => ['pos' => $nama, 'nilai' => $nilai];

        $laporan = Laporan::buat('Neraca', 'neraca')
            ->periode($tanggal)
            ->ringkasan([
                'Total Aset' => Laporan::format($p->total_aset, 'rupiah'),
                'Total Kewajiban' => Laporan::format($p->total_kewajiban, 'rupiah'),
                'Total Modal' => Laporan::format($p->total_modal, 'rupiah'),
                'Selisih belum tercatat' => Laporan::format($p->selisih, 'rupiah'),
            ])
            ->bagian('ASET', [
                ['label' => 'Pos', 'key' => 'pos', 'lebar' => 46],
                ['label' => 'Nilai', 'key' => 'nilai', 'format' => 'rupiah', 'lebar' => 20],
            ], [
                $pos('Kas & setara kas', $p->kas),
                $pos('Persediaan barang', $p->persediaan),
                $pos('Aset tetap (setelah penyusutan)', $p->aset_tetap),
            ], ['pos' => 'TOTAL ASET', 'nilai' => $p->total_aset])
            ->bagian('KEWAJIBAN', [
                ['label' => 'Pos', 'key' => 'pos', 'lebar' => 46],
                ['label' => 'Nilai', 'key' => 'nilai', 'format' => 'rupiah', 'lebar' => 20],
            ], [
                $pos('Hutang usaha ke pemasok', $p->hutang_usaha),
                $pos('Uang muka pelanggan', $p->uang_muka),
            ], ['pos' => 'TOTAL KEWAJIBAN', 'nilai' => $p->total_kewajiban])
            ->bagian('MODAL', [
                ['label' => 'Pos', 'key' => 'pos', 'lebar' => 46],
                ['label' => 'Nilai', 'key' => 'nilai', 'format' => 'rupiah', 'lebar' => 20],
            ], [
                $pos('Modal awal', $p->modal_awal),
                $pos('Tambahan modal', $p->tambahan_modal),
                $pos('Prive (pengambilan pemilik)', -$p->prive),
                $pos('Laba ditahan', $p->laba_ditahan),
            ], ['pos' => 'TOTAL MODAL', 'nilai' => $p->total_modal])
            ->bagian('PEMERIKSAAN KESEIMBANGAN', [
                ['label' => 'Uraian', 'key' => 'pos', 'lebar' => 46],
                ['label' => 'Nilai', 'key' => 'nilai', 'format' => 'rupiah', 'lebar' => 20],
            ], [
                $pos('Total Aset', $p->total_aset),
                $pos('Total Kewajiban + Modal', Angka::bulat($p->total_kewajiban + $p->total_modal)),
            ], ['pos' => 'SELISIH (seharusnya nol)', 'nilai' => $p->selisih]);

        $laporan->catatan(
            'Aset = Kewajiban + Modal. Kalau kedua sisi tidak sama, ada transaksi yang menggerakkan satu sisi saja dan belum tercatat.',
            'Barang pesanan DP tetap dihitung sebagai persediaan karena belum diserahkan, dan uang mukanya dicatat sebagai kewajiban - toko masih berhutang barang kepada pembelinya.',
            'Nilai persediaan memakai stok dan harga modal SAAT INI, jadi neraca hanya sahih untuk tanggal hari ini kecuali sudah dibekukan lewat Tutup Buku.',
            self::CATATAN_MODAL,
        );

        if ($p->sisa_tagihan_pesanan > 0) {
            $laporan->catatan(
                'Sisa tagihan pesanan DP ' . Laporan::format($p->sisa_tagihan_pesanan, 'rupiah')
                . ' sengaja TIDAK dimasukkan ke neraca: barangnya belum diserahkan sehingga penjualannya belum boleh diakui.'
            );
        }

        if (abs($p->selisih) >= 0.01) {
            $laporan->catatan(
                'PERHATIAN: neraca belum seimbang. Penyebab tersering - stok disesuaikan lewat Master Produk tanpa dicatat sebagai Pembelian, modal awal belum diisi dengan benar, atau ada peralatan toko yang belum didaftarkan sebagai aset tetap.'
            );
        }

        return $laporan;
    }

    /* ==================================================================== PENJUALAN */

    private function laporanPenjualan(Request $request): Laporan
    {
        [$dari, $sampai] = $this->rentang($request);

        // Penyaring metode dijaga sama persis dengan yang di layar (ReportController::penjualan).
        // Kalau tidak, pemilik toko yang menyaring "QRIS" lalu menekan Unduh PDF akan
        // mendapat berkas berisi SELURUH transaksi - dan tidak akan sadar sampai ia
        // memakainya untuk menagih.
        $metode = in_array($request->metode, MetodeBayar::kunci(), true) ? $request->metode : null;

        // Status pesanan dijaga sama persis dengan yang di layar, dengan alasan yang sama.
        // Nilai karangan diabaikan, bukan diteruskan mentah ke query.
        $status = in_array($request->order_status, ['completed', 'waiting'], true)
            ? $request->order_status
            : null;

        $penjualan = Sale::with(['customer', 'cashier', 'payments'])
            ->whereDate('created_at', '>=', $dari)
            ->whereDate('created_at', '<=', $sampai)
            ->where('order_status', '<>', 'cancelled')
            ->when($status, fn ($q) => $q->where('order_status', $status))
            ->when($metode, fn ($q) => $q->whereHas('payments', fn ($p) => $p->where('method', $metode)))
            ->orderBy('created_at')
            ->get()
            ->map(fn (Sale $s) => [
                'tanggal' => $s->created_at->format('d/m/Y H:i'),
                'invoice' => $s->invoice_no,
                'pelanggan' => $s->customer->name ?? 'Umum',
                'kasir' => $s->cashier->name ?? '-',
                'metode' => $s->payments->isEmpty()
                    ? '-'
                    : $s->payments->map(fn ($b) => MetodeBayar::label($b->method))->unique()->implode(', '),
                'status' => $this->labelStatus($s->order_status) . ($s->status === 'returned' ? ' (Diretur)' : ''),
                'diskon' => (float) $s->discount,
                'pajak' => (float) $s->tax_amount,
                'total' => (float) $s->total,
            ]);

        // Rincian per status - hanya transaksi aktif (selesai dan menunggu DP).
        // Transaksi yang dibatalkan tidak dilaporkan dan tidak dihitung ke total.
        $perStatus = Sale::whereDate('created_at', '>=', $dari)
            ->whereDate('created_at', '<=', $sampai)
            ->where('order_status', '<>', 'cancelled')
            ->when($status, fn ($q) => $q->where('order_status', $status))
            ->selectRaw('order_status, COUNT(*) as jumlah, SUM(total) as nilai')
            ->groupBy('order_status')
            ->get()
            ->map(fn ($r) => [
                'status' => $this->labelStatus($r->order_status),
                'jumlah' => (int) $r->jumlah,
                'nilai' => (float) $r->nilai,
                'catatan' => match ($r->order_status) {
                    'completed' => 'dihitung sebagai omset',
                    'waiting' => 'piutang, belum jadi omset',
                    default => '-',
                },
            ]);

        // Uang yang benar-benar diterima pada rentang ini, dikelompokkan per metode.
        // Angkanya SENGAJA tidak sama dengan jumlah kolom Total - alasannya ada di catatan
        // di bawah, dan ikut tercetak supaya tidak dikira laporannya rusak.
        $uangMasuk = SalePayment::query()
            ->join('sales', 'sales.id', '=', 'sale_payments.sale_id')
            ->whereDate('sale_payments.created_at', '>=', $dari)
            ->whereDate('sale_payments.created_at', '<=', $sampai)
            ->where('sales.order_status', '<>', 'cancelled')
            ->when($metode, fn ($q) => $q->where('sale_payments.method', $metode))
            ->selectRaw('sale_payments.method, COUNT(*) as jumlah, SUM(sale_payments.amount) as nilai')
            ->groupBy('sale_payments.method')
            ->get()
            ->map(fn ($b) => [
                'metode' => MetodeBayar::label($b->method),
                'jumlah' => (int) $b->jumlah,
                'nilai' => (float) $b->nilai,
            ]);

        $totalUangMasuk = (float) $uangMasuk->sum('nilai');
        $uangTunai = (float) ($uangMasuk->firstWhere('metode', MetodeBayar::label('tunai'))['nilai'] ?? 0.0);
        $totalNonTunai = $totalUangMasuk - $uangTunai;

        $penjualanLunas = $penjualan->filter(fn ($s) => str_starts_with($s['status'], 'Selesai'));
        $totalSemua = $penjualan->sum('total');
        $totalLunas = $penjualanLunas->sum('total');

        $ringkasan = [];
        if ($status) {
            $ringkasan['Filter Status'] = $this->labelStatus($status);
            $ringkasan['Jumlah Transaksi'] = number_format($penjualan->count(), 0, ',', '.');
            $ringkasan['Total Nilai Transaksi'] = Laporan::format($totalSemua, 'rupiah');
            $ringkasan['Total Diskon'] = Laporan::format($penjualan->sum('diskon'), 'rupiah');
            $ringkasan['Total Pajak Dipungut'] = Laporan::format($penjualan->sum('pajak'), 'rupiah');
        } else {
            $ringkasan['Total Pendapatan (Lunas)'] = Laporan::format($totalLunas, 'rupiah');
            $ringkasan['Transaksi Lunas (Omset)'] = number_format($penjualanLunas->count(), 0, ',', '.') . ' transaksi';
            $ringkasan['Total Diskon (Lunas)'] = Laporan::format($penjualanLunas->sum('diskon'), 'rupiah');
            $ringkasan['Total Pajak (Lunas)'] = Laporan::format($penjualanLunas->sum('pajak'), 'rupiah');
            if ($penjualan->count() !== $penjualanLunas->count()) {
                $ringkasan['Total Seluruh Transaksi'] = Laporan::format($totalSemua, 'rupiah') . ' (' . $penjualan->count() . ' transaksi)';
            }
        }

        if ($metode) {
            $ringkasan['Filter Metode Bayar'] = MetodeBayar::label($metode);
        }
        $ringkasan['Total Uang Masuk Diterima'] = Laporan::format($totalUangMasuk, 'rupiah') . ' (Non-Tunai: ' . Laporan::format($totalNonTunai, 'rupiah') . ')';

        return Laporan::buat('Laporan Penjualan', 'penjualan')
            ->periode($dari, $sampai)
            ->ringkasan($ringkasan)
            ->bagian('Rincian Transaksi', [
                ['label' => 'Waktu', 'key' => 'tanggal', 'lebar' => 18],
                ['label' => 'No. Invoice', 'key' => 'invoice', 'lebar' => 20],
                ['label' => 'Pelanggan', 'key' => 'pelanggan', 'lebar' => 24],
                ['label' => 'Kasir', 'key' => 'kasir', 'lebar' => 18],
                ['label' => 'Metode Bayar', 'key' => 'metode', 'lebar' => 20],
                ['label' => 'Status', 'key' => 'status', 'lebar' => 14],
                ['label' => 'Diskon', 'key' => 'diskon', 'format' => 'rupiah'],
                ['label' => 'Pajak', 'key' => 'pajak', 'format' => 'rupiah'],
                ['label' => 'Total', 'key' => 'total', 'format' => 'rupiah'],
            ], $penjualan->all(), [
                'tanggal' => 'TOTAL',
                'diskon' => $penjualan->sum('diskon'),
                'pajak' => $penjualan->sum('pajak'),
                'total' => $penjualan->sum('total'),
            ])
            ->bagian('Rincian Seluruh Transaksi', [
                ['label' => 'Status Pesanan', 'key' => 'status', 'lebar' => 20],
                ['label' => 'Jumlah', 'key' => 'jumlah'],
                ['label' => 'Nilai', 'key' => 'nilai', 'format' => 'rupiah'],
                ['label' => 'Keterangan', 'key' => 'catatan', 'lebar' => 30],
            ], $perStatus->all(), [
                'status' => 'JUMLAH SEMUANYA',
                'jumlah' => $perStatus->sum('jumlah'),
                'nilai' => $perStatus->sum('nilai'),
            ])
            ->bagian('Uang Masuk per Metode', [
                ['label' => 'Metode Pembayaran', 'key' => 'metode', 'lebar' => 24],
                ['label' => 'Jumlah Penerimaan', 'key' => 'jumlah'],
                ['label' => 'Nilai', 'key' => 'nilai', 'format' => 'rupiah'],
            ], $uangMasuk->all(), [
                'metode' => 'TOTAL',
                'jumlah' => $uangMasuk->sum('jumlah'),
                'nilai' => $uangMasuk->sum('nilai'),
            ])
            ->catatan(
                'Kolom Total memuat pajak, karena ini nilai yang benar-benar dibayar pembeli. Untuk omset tanpa pajak, lihat Laporan Laba Rugi.',
                'Transaksi yang dibatalkan tidak dimasukkan ke dalam laporan dan tidak dihitung ke dalam total transaksi.',
                'Uang Masuk per Metode menghitung uang yang BENAR-BENAR diterima pada rentang tanggal ini: Total ' . Laporan::format($totalUangMasuk, 'rupiah') . ' (Tunai: ' . Laporan::format($uangTunai, 'rupiah') . ', Non-Tunai: ' . Laporan::format($totalNonTunai, 'rupiah') . '). Inilah angka yang diadu dengan isi laci dan mutasi rekening.',
                'Pada Rincian Transaksi, hanya transaksi berstatus aktif yang dilaporkan (Selesai dan Menunggu DP). Yang benar-benar dihitung sebagai omset adalah baris berstatus Selesai.',
            );
    }

    /* ======================================================================== OMSET */

    private function laporanOmset(Request $request): Laporan
    {
        [$dari, $sampai] = $this->rentang($request);

        $omset = Akuntansi::omsetHarian($dari, $sampai);

        $jumlahTransaksi = Sale::whereDate('created_at', '>=', $dari)
            ->whereDate('created_at', '<=', $sampai)
            ->where('order_status', 'completed')
            ->selectRaw('DATE(created_at) as tanggal, COUNT(*) as jumlah')
            ->groupBy('tanggal')
            ->pluck('jumlah', 'tanggal');

        $baris = collect(array_keys($omset + $jumlahTransaksi->all()))
            ->unique()->sort()->values()
            ->map(fn (string $t) => [
                'tanggal' => $t,
                'transaksi' => (int) ($jumlahTransaksi[$t] ?? 0),
                'omset' => $omset[$t] ?? 0.0,
                'rata_rata' => ($jumlahTransaksi[$t] ?? 0) > 0
                    ? Angka::bulat(($omset[$t] ?? 0) / $jumlahTransaksi[$t])
                    : 0.0,
            ]);

        return Laporan::buat('Laporan Omset', 'omset')
            ->periode($dari, $sampai)
            ->ringkasan([
                'Total Omset Bersih' => Laporan::format($baris->sum('omset'), 'rupiah'),
                'Jumlah Transaksi' => number_format($baris->sum('transaksi'), 0, ',', '.'),
                'Rata-rata per Transaksi' => Laporan::format(
                    $baris->sum('transaksi') > 0 ? $baris->sum('omset') / $baris->sum('transaksi') : 0,
                    'rupiah'
                ),
                'Pajak Dipungut' => Laporan::format(Akuntansi::pajakDipungut($dari, $sampai), 'rupiah'),
            ])
            ->bagian('Omset Harian', [
                ['label' => 'Tanggal', 'key' => 'tanggal', 'format' => 'tanggal', 'lebar' => 16],
                ['label' => 'Jumlah Transaksi', 'key' => 'transaksi', 'format' => 'angka'],
                ['label' => 'Omset Bersih', 'key' => 'omset', 'format' => 'rupiah'],
                ['label' => 'Rata-rata / Transaksi', 'key' => 'rata_rata', 'format' => 'rupiah'],
            ], $baris->all(), [
                'tanggal' => 'TOTAL',
                'transaksi' => $baris->sum('transaksi'),
                'omset' => $baris->sum('omset'),
            ])
            ->catatan(self::CATATAN_PAJAK, self::CATATAN_RETUR);
    }

    /* ========================================================================= STOK */

    private function laporanStok(Request $request): Laporan
    {
        $q = trim((string) $request->q);
        $lowStock = $request->boolean('low_stock');

        $produk = Product::with(['category', 'rackSlot.rack'])
            ->where('type', 'barang')
            ->when($q !== '', fn ($query) => $query->where('name', 'like', "%{$q}%"))
            ->when($lowStock, fn ($query) => $query->whereColumn('stock', '<=', 'min_stock'))
            ->orderBy('name')
            ->get();

        $baris = $produk->map(fn (Product $p) => [
            'nama' => $p->name,
            'sku' => $p->sku ?: '-',
            'barcode' => $p->barcode ?: '-',
            'kategori' => $p->category->name ?? '-',
            'lokasi' => $p->rackSlot?->label() ?: '-',
            'stok' => (float) $p->stock,
            'satuan' => $p->unit ?: 'Pcs',
            'min' => (float) $p->min_stock,
            'status' => $p->isLowStock() ? 'Menipis' : 'Aman',
            'modal' => (float) $p->cost_price,
            'jual' => (float) $p->sell_price,
            'nilai' => Angka::bulat((float) $p->stock * (float) $p->cost_price),
        ]);

        $menipis = $produk->filter(fn (Product $p) => $p->isLowStock())->count();

        $ringkasan = [
            'Jumlah Jenis Barang' => number_format($produk->count(), 0, ',', '.'),
            'Nilai Persediaan' => Laporan::format($baris->sum('nilai'), 'rupiah'),
            'Barang Stok Menipis' => number_format($menipis, 0, ',', '.') . ' jenis',
        ];

        if ($lowStock) {
            $ringkasan['Filter Stok'] = 'Hanya Stok Menipis';
        }
        if ($q !== '') {
            $ringkasan['Pencarian'] = $q;
        }

        return Laporan::buat('Laporan Stok & Nilai Persediaan', 'stok')
            ->periode(now()->toDateString())
            ->ringkasan($ringkasan)
            ->bagian('Rincian Persediaan', [
                ['label' => 'Nama Produk', 'key' => 'nama', 'lebar' => 26],
                ['label' => 'SKU', 'key' => 'sku', 'lebar' => 12],
                ['label' => 'Barcode', 'key' => 'barcode', 'lebar' => 14],
                ['label' => 'Kategori', 'key' => 'kategori', 'lebar' => 14],
                ['label' => 'Lokasi Rak', 'key' => 'lokasi', 'lebar' => 12],
                ['label' => 'Stok', 'key' => 'stok', 'format' => 'angka'],
                ['label' => 'Satuan', 'key' => 'satuan', 'lebar' => 8],
                ['label' => 'Min. Stok', 'key' => 'min', 'format' => 'angka'],
                ['label' => 'Status', 'key' => 'status', 'lebar' => 10],
                ['label' => 'Harga Modal', 'key' => 'modal', 'format' => 'rupiah'],
                ['label' => 'Harga Jual', 'key' => 'jual', 'format' => 'rupiah'],
                ['label' => 'Nilai Persediaan', 'key' => 'nilai', 'format' => 'rupiah'],
            ], $baris->all(), [
                'nama' => 'TOTAL',
                'nilai' => $baris->sum('nilai'),
            ])
            ->catatan(
                'Nilai persediaan = stok x harga modal terkini. Angka ini yang masuk sebagai pos Persediaan di Neraca.',
                'Produk jasa tidak ditampilkan karena tidak punya stok fisik.',
                'Lokasi rak diambil dari Planogram. Tanda "-" berarti produknya belum ditaruh di rak mana pun.',
            );
    }

    /* =================================================================== STOK OPNAME */

    private function laporanStokOpname(Request $request): Laporan
    {
        $q = trim((string) $request->q);
        $categoryId = $request->category_id;
        $rackId = $request->rack_id;
        $lowStock = $request->boolean('low_stock');
        $sortBy = $request->get('sort_by', 'name');

        $query = Product::with(['category', 'rackSlot.rack'])
            ->where('type', 'barang')
            ->when($q !== '', function ($subQuery) use ($q) {
                $subQuery->where(function ($sub) use ($q) {
                    $sub->where('name', 'like', "%{$q}%")
                        ->orWhere('sku', 'like', "%{$q}%")
                        ->orWhere('barcode', 'like', "%{$q}%");
                });
            })
            ->when($categoryId, fn ($subQuery) => $subQuery->where('category_id', $categoryId))
            ->when($rackId, function ($subQuery) use ($rackId) {
                $subQuery->whereHas('rackSlot', fn ($slot) => $slot->where('rack_id', $rackId));
            })
            ->when($lowStock, fn ($subQuery) => $subQuery->whereColumn('stock', '<=', 'min_stock'));

        if ($sortBy === 'category') {
            $query->leftJoin('categories', 'categories.id', '=', 'products.category_id')
                ->orderBy('categories.name')
                ->orderBy('products.name')
                ->select('products.*');
        } elseif ($sortBy === 'stock_asc') {
            $query->orderBy('stock', 'asc');
        } elseif ($sortBy === 'stock_desc') {
            $query->orderBy('stock', 'desc');
        } else {
            $query->orderBy('name', 'asc');
        }

        $produk = $query->get();

        $no = 1;
        $baris = $produk->map(fn (Product $p) => [
            'no' => $no++,
            'sku' => $p->sku ?: '-',
            'barcode' => $p->barcode ?: '-',
            'nama' => $p->name,
            'kategori' => $p->category->name ?? '-',
            'lokasi' => $p->rackSlot?->label() ?: '-',
            'satuan' => $p->unit ?: 'Pcs',
            'stok_sistem' => (float) $p->stock,
            'stok_fisik' => '',
            'selisih' => '',
            'modal' => (float) $p->cost_price,
            'jual' => (float) $p->sell_price,
            'total_modal' => Angka::bulat((float) $p->stock * (float) $p->cost_price),
            'total_jual' => Angka::bulat((float) $p->stock * (float) $p->sell_price),
        ]);

        $ringkasan = [
            'Total Jenis Barang' => number_format($produk->count(), 0, ',', '.') . ' jenis',
            'Total Stok Sistem' => number_format($baris->sum('stok_sistem'), 2, ',', '.'),
            'Total Nilai Modal (HPP)' => Laporan::format($baris->sum('total_modal'), 'rupiah'),
            'Total Potensi Nilai Jual' => Laporan::format($baris->sum('total_jual'), 'rupiah'),
        ];

        if ($q !== '') {
            $ringkasan['Filter Pencarian'] = $q;
        }
        if ($lowStock) {
            $ringkasan['Filter Stok'] = 'Hanya Stok Menipis';
        }

        return Laporan::buat('Lembar Cek Stok Opname', 'stok-opname')
            ->periode(now()->toDateString())
            ->ringkasan($ringkasan)
            ->bagian('Daftar Produk untuk Cek Stok Opname', [
                ['label' => 'No', 'key' => 'no', 'lebar' => 5],
                ['label' => 'SKU', 'key' => 'sku', 'lebar' => 12],
                ['label' => 'Barcode', 'key' => 'barcode', 'lebar' => 15],
                ['label' => 'Nama Produk', 'key' => 'nama', 'lebar' => 26],
                ['label' => 'Kategori', 'key' => 'kategori', 'lebar' => 14],
                ['label' => 'Lokasi Rak', 'key' => 'lokasi', 'lebar' => 12],
                ['label' => 'Satuan', 'key' => 'satuan', 'lebar' => 8],
                ['label' => 'Stok Komputer', 'key' => 'stok_sistem', 'format' => 'angka'],
                ['label' => 'Cek Fisik', 'key' => 'stok_fisik', 'lebar' => 12],
                ['label' => 'Selisih', 'key' => 'selisih', 'lebar' => 10],
                ['label' => 'Harga Modal', 'key' => 'modal', 'format' => 'rupiah'],
                ['label' => 'Harga Jual', 'key' => 'jual', 'format' => 'rupiah'],
                ['label' => 'Nilai Modal', 'key' => 'total_modal', 'format' => 'rupiah'],
                ['label' => 'Nilai Jual', 'key' => 'total_jual', 'format' => 'rupiah'],
            ], $baris->all(), [
                'nama' => 'TOTAL',
                'stok_sistem' => $baris->sum('stok_sistem'),
                'total_modal' => $baris->sum('total_modal'),
                'total_jual' => $baris->sum('total_jual'),
            ])
            ->catatan(
                'Lembar kerja ini digunakan untuk audit penghitungan fisik stok barang di rak toko (Stok Opname).',
                'Isi kolom "Cek Fisik" secara langsung dengan kuantitas barang fisik yang ditemukan di rak saat pemeriksaan.',
                'Selisih = Stok Fisik - Stok Komputer. Selisih negatif menunjukkan kehilangan/penyusutan, selisih positif menunjukkan kelebihan/salah catat.',
                'Harga Modal dan Harga Jual disertakan sebagai acuan nilai valuasi aset toko dan estimasi dampak selisih barang.'
            );
    }

    /* =================================================================== MUTASI STOK */

    private function laporanMutasiStok(Request $request): Laporan
    {
        [$dari, $sampai] = $this->rentang($request);
        $q = trim((string) $request->q);
        $categoryId = $request->category_id;
        $hanyaAdaMutasi = $request->boolean('hanya_ada_mutasi');

        $beliSub = DB::table('purchase_items')
            ->join('purchases', 'purchases.id', '=', 'purchase_items.purchase_id')
            ->whereDate('purchases.purchase_date', '>=', $dari)
            ->whereDate('purchases.purchase_date', '<=', $sampai)
            ->select('purchase_items.product_id', DB::raw('SUM(purchase_items.qty * COALESCE(purchase_items.unit_conversion, 1)) as total_beli'))
            ->groupBy('purchase_items.product_id');

        $jualSub = DB::table('sale_items')
            ->join('sales', 'sales.id', '=', 'sale_items.sale_id')
            ->where('sales.order_status', '=', 'completed')
            ->whereDate('sales.created_at', '>=', $dari)
            ->whereDate('sales.created_at', '<=', $sampai)
            ->select('sale_items.product_id', DB::raw('SUM((sale_items.qty - COALESCE(sale_items.returned_qty, 0)) * COALESCE(sale_items.unit_conversion, 1)) as total_jual'))
            ->groupBy('sale_items.product_id');

        $query = Product::query()
            ->with('category')
            ->where('type', 'barang')
            ->leftJoinSub($beliSub, 'beli', fn ($join) => $join->on('products.id', '=', 'beli.product_id'))
            ->leftJoinSub($jualSub, 'jual', fn ($join) => $join->on('products.id', '=', 'jual.product_id'))
            ->select(
                'products.*',
                DB::raw('COALESCE(beli.total_beli, 0) as total_masuk'),
                DB::raw('COALESCE(jual.total_jual, 0) as total_keluar'),
                DB::raw('MAX(0, (COALESCE(products.stock, 0) - COALESCE(beli.total_beli, 0) + COALESCE(jual.total_jual, 0))) as stok_awal')
            );

        if ($q !== '') {
            $query->where(function ($w) use ($q) {
                $w->where('products.name', 'like', "%{$q}%")
                  ->orWhere('products.barcode', 'like', "%{$q}%");
            });
        }

        if ($categoryId) {
            $query->where('products.category_id', $categoryId);
        }

        if ($hanyaAdaMutasi) {
            $query->where(function ($w) {
                $w->where('beli.total_beli', '>', 0)
                  ->orWhere('jual.total_jual', '>', 0);
            });
        }

        $produk = $query->orderBy('products.name')->get();

        $baris = $produk->map(fn (Product $p) => [
            'nama' => $p->name,
            'barcode' => $p->barcode ?: '-',
            'kategori' => $p->category->name ?? '-',
            'satuan' => $p->unit ?: 'Pcs',
            'stok_awal' => (float) $p->stok_awal,
            'masuk' => (float) $p->total_masuk,
            'keluar' => (float) $p->total_keluar,
            'stok' => (float) $p->stock,
        ]);

        $ringkasan = [
            'Total Jenis Produk' => number_format($baris->count(), 0, ',', '.'),
            'Total Stok Awal' => number_format($baris->sum('stok_awal'), 2, ',', '.'),
            'Total Qty Kulakan Masuk' => number_format($baris->sum('masuk'), 2, ',', '.'),
            'Total Qty Terjual Keluar' => number_format($baris->sum('keluar'), 2, ',', '.'),
            'Total Sisa Stok' => number_format($baris->sum('stok'), 2, ',', '.'),
        ];

        return Laporan::buat('Laporan Rekap Mutasi Stok', 'mutasi-stok')
            ->periode($dari, $sampai)
            ->ringkasan($ringkasan)
            ->bagian('Rincian Mutasi Barang', [
                ['label' => 'Nama Produk', 'key' => 'nama', 'lebar' => 30],
                ['label' => 'Barcode', 'key' => 'barcode', 'lebar' => 15],
                ['label' => 'Kategori', 'key' => 'kategori', 'lebar' => 15],
                ['label' => 'Satuan', 'key' => 'satuan', 'lebar' => 8],
                ['label' => 'Stok Awal', 'key' => 'stok_awal', 'format' => 'angka'],
                ['label' => 'Masuk (Beli)', 'key' => 'masuk', 'format' => 'angka'],
                ['label' => 'Keluar (Jual)', 'key' => 'keluar', 'format' => 'angka'],
                ['label' => 'Sisa Stok', 'key' => 'stok', 'format' => 'angka'],
            ], $baris->all(), [
                'nama' => 'TOTAL',
                'stok_awal' => $baris->sum('stok_awal'),
                'masuk' => $baris->sum('masuk'),
                'keluar' => $baris->sum('keluar'),
                'stok' => $baris->sum('stok'),
            ])
            ->catatan(
                'Stok Awal memperkirakan posisi stok sebelum pergerakan pada periode terpilih (Stok Akhir - Masuk + Keluar).',
                'Barang Masuk dihitung dari seluruh nota pembelian distributor pada rentang tanggal terpilih.',
                'Barang Keluar dihitung dari seluruh penjualan berstatus selesai dikurangi retur pada rentang tanggal terpilih.',
                'Sisa Stok menunjukkan posisi fisik stok saat ini yang siap dijual di toko.',
                'Produk jasa tidak ditampilkan karena tidak memiliki pergerakan fisik barang.'
            );
    }

    /* =================================================================== REKAP PEMBELIAN */

    private function laporanRekapPembelian(Request $request): Laporan
    {
        [$dari, $sampai] = $this->rentang($request);
        $q = trim((string) $request->q);
        $supplierId = $request->supplier_id;

        $query = DB::table('purchase_items')
            ->join('purchases', 'purchases.id', '=', 'purchase_items.purchase_id')
            ->leftJoin('products', 'products.id', '=', 'purchase_items.product_id')
            ->leftJoin('suppliers', 'suppliers.id', '=', 'purchases.supplier_id');

        if ($request->periode !== 'semua') {
            if ($request->periode === 'hari_ini') {
                $dari = today()->toDateString();
                $sampai = today()->toDateString();
            } elseif ($request->periode === '7_hari') {
                $dari = now()->subDays(7)->toDateString();
                $sampai = today()->toDateString();
            } elseif ($request->periode === 'bulan_lalu') {
                $dari = now()->subMonth()->startOfMonth()->toDateString();
                $sampai = now()->subMonth()->endOfMonth()->toDateString();
            } elseif ($request->periode === 'bulan_ini' || empty($request->periode)) {
                if (! $request->filled('from')) {
                    $dari = now()->startOfMonth()->toDateString();
                    $sampai = now()->endOfMonth()->toDateString();
                }
            }

            if ($dari && $sampai) {
                $query->whereDate('purchases.purchase_date', '>=', $dari)
                      ->whereDate('purchases.purchase_date', '<=', $sampai);
            }
        } else {
            $dari = null;
            $sampai = null;
        }

        if ($supplierId) {
            $query->where('purchases.supplier_id', $supplierId);
        }

        if ($q !== '') {
            $query->where(function ($w) use ($q) {
                $w->where('purchase_items.product_name', 'like', "%{$q}%")
                  ->orWhere('products.name', 'like', "%{$q}%")
                  ->orWhere('products.barcode', 'like', "%{$q}%")
                  ->orWhere('products.sku', 'like', "%{$q}%");
            });
        }

        $items = $query
            ->select(
                'purchase_items.product_id',
                DB::raw('COALESCE(products.name, purchase_items.product_name) as nama_produk'),
                DB::raw('COALESCE(products.barcode, "-") as barcode'),
                DB::raw('COALESCE(products.sku, "-") as sku'),
                DB::raw('COALESCE(products.unit, purchase_items.unit_label) as satuan_dasar'),
                DB::raw('COALESCE(products.stock, 0) as sisa_stok_toko'),
                DB::raw('SUM(purchase_items.qty * COALESCE(purchase_items.unit_conversion, 1)) as total_base_qty'),
                DB::raw('SUM(purchase_items.subtotal) as total_nominal'),
                DB::raw('COUNT(DISTINCT purchase_items.purchase_id) as jumlah_faktur'),
                DB::raw('MAX(purchases.purchase_date) as tgl_faktur_terakhir')
            )
            ->groupBy('purchase_items.product_id', 'nama_produk', 'barcode', 'sku', 'satuan_dasar', 'sisa_stok_toko');

        $urut = $request->get('urut', 'terbaru');
        switch ($urut) {
            case 'nominal_desc':
                $query->orderByDesc('total_nominal');
                break;
            case 'nominal_asc':
                $query->orderBy('total_nominal');
                break;
            case 'qty_desc':
                $query->orderByDesc('total_base_qty');
                break;
            case 'nama_asc':
                $query->orderBy('nama_produk');
                break;
            case 'terbaru':
            default:
                $query->orderByDesc('tgl_faktur_terakhir')->orderByDesc('total_nominal');
                break;
        }

        $items = $query->get();

        $baris = $items->map(fn ($p) => [
            'nama' => $p->nama_produk,
            'barcode' => $p->barcode ?: '-',
            'satuan' => $p->satuan_dasar ?: 'Pcs',
            'qty_masuk' => (float) $p->total_base_qty,
            'avg_modal' => (float) ($p->total_base_qty > 0 ? round($p->total_nominal / $p->total_base_qty, 2) : 0),
            'total_nominal' => (float) $p->total_nominal,
            'jumlah_faktur' => (int) $p->jumlah_faktur,
            'stok_toko' => (float) $p->sisa_stok_toko,
        ]);

        $totalNominal = (float) $baris->sum('total_nominal');
        $totalQty = (float) $baris->sum('qty_masuk');
        $totalProduk = $baris->count();
        $totalFaktur = (int) $baris->sum('jumlah_faktur');

        $ringkasan = [
            'Total Nilai Kulakan' => 'Rp ' . number_format($totalNominal, 0, ',', '.'),
            'Total Jenis Produk' => number_format($totalProduk, 0, ',', '.') . ' Produk',
            'Total Qty Masuk Fisik' => number_format($totalQty, 2, ',', '.') . ' Satuan Dasar',
            'Total Transaksi Faktur' => number_format($totalFaktur, 0, ',', '.') . ' Faktur',
        ];

        return Laporan::buat('Laporan Rekap Pembelian Barang', 'rekap-pembelian')
            ->periode($dari, $sampai)
            ->ringkasan($ringkasan)
            ->bagian('Rincian Akumulasi Belanja Barang', [
                ['label' => 'Nama Produk', 'key' => 'nama', 'lebar' => 32],
                ['label' => 'Barcode', 'key' => 'barcode', 'lebar' => 16],
                ['label' => 'Satuan', 'key' => 'satuan', 'lebar' => 10],
                ['label' => 'Total Qty Beli', 'key' => 'qty_masuk', 'format' => 'angka'],
                ['label' => 'Rata-rata Modal', 'key' => 'avg_modal', 'format' => 'rupiah'],
                ['label' => 'Total Belanja', 'key' => 'total_nominal', 'format' => 'rupiah'],
                ['label' => 'Jml Faktur', 'key' => 'jumlah_faktur', 'format' => 'angka'],
                ['label' => 'Sisa Stok Toko', 'key' => 'stok_toko', 'format' => 'angka'],
            ], $baris->all(), [
                'nama' => 'TOTAL',
                'qty_masuk' => $totalQty,
                'total_nominal' => $totalNominal,
            ])
            ->catatan(
                'Kuantitas pembelian di atas adalah akumulasi murni barang masuk dari faktur supplier dalam periode terpilih.',
                'Kuantitas ini TIDAK berkurang saat kasir menjual barang, karena berfungsi sebagai catatan belanja modal toko.',
                'Rata-rata modal dihitung dari total nominal belanja dibagi total kuantitas satuan dasar yang masuk.',
                'Sisa Stok Toko menunjukkan saldo fisik stok di rak toko saat ini sebagai pembanding.'
            );
    }

    /* ===================================================================== TERLARIS */

    private function laporanTerlaris(Request $request): Laporan
    {
        [$dari, $sampai] = $this->rentang($request);

        $baris = SaleItem::select('product_name')
            ->selectRaw('SUM(qty * unit_conversion) as total_qty, SUM(subtotal) as total_nilai')
            ->whereHas('sale', fn ($q) => $q->whereDate('created_at', '>=', $dari)
                ->whereDate('created_at', '<=', $sampai)
                ->where('order_status', 'completed'))
            ->groupBy('product_name')
            ->orderByDesc('total_qty')
            ->get()
            ->values()
            ->map(fn ($r, $i) => [
                'urutan' => $i + 1,
                'nama' => $r->product_name,
                'qty' => (float) $r->total_qty,
                'nilai' => (float) $r->total_nilai,
            ]);

        return Laporan::buat('Laporan Produk Terlaris', 'produk-terlaris')
            ->periode($dari, $sampai)
            ->ringkasan([
                'Jenis Produk Terjual' => number_format($baris->count(), 0, ',', '.'),
                'Total Nilai Penjualan' => Laporan::format($baris->sum('nilai'), 'rupiah'),
            ])
            ->bagian('Peringkat Penjualan', [
                ['label' => 'No.', 'key' => 'urutan', 'format' => 'angka', 'lebar' => 8],
                ['label' => 'Nama Produk', 'key' => 'nama', 'lebar' => 42],
                ['label' => 'Jumlah Terjual', 'key' => 'qty', 'format' => 'angka'],
                ['label' => 'Nilai Penjualan', 'key' => 'nilai', 'format' => 'rupiah'],
            ], $baris->all(), [
                'urutan' => null,
                'nama' => 'TOTAL',
                'nilai' => $baris->sum('nilai'),
            ])
            ->catatan(
                'Jumlah terjual dinyatakan dalam SATUAN DASAR produk. Penjualan 2 Dus @ 40 Pcs terhitung 80, bukan 2.',
                'Nama produk diambil dari catatan saat transaksi, jadi produk yang namanya sudah diubah tetap muncul dengan nama lamanya.',
                'Hanya transaksi selesai yang dihitung.',
            );
    }

    /* ================================================================ PER PELANGGAN */

    private function laporanPerPelanggan(Request $request): Laporan
    {
        [$dari, $sampai] = $this->rentang($request);

        $baris = Sale::leftJoin('customers', 'customers.id', '=', 'sales.customer_id')
            ->whereDate('sales.created_at', '>=', $dari)
            ->whereDate('sales.created_at', '<=', $sampai)
            ->where('sales.order_status', 'completed')
            ->selectRaw("COALESCE(customers.name, 'Umum') as nama, COUNT(*) as transaksi, SUM(sales.total) as belanja")
            ->groupBy('sales.customer_id', 'customers.name')
            ->orderByDesc('belanja')
            ->get()
            ->map(fn ($r) => [
                'nama' => $r->nama,
                'transaksi' => (float) $r->transaksi,
                'belanja' => (float) $r->belanja,
                'rata_rata' => $r->transaksi > 0 ? Angka::bulat($r->belanja / $r->transaksi) : 0.0,
            ]);

        return Laporan::buat('Laporan Penjualan per Pelanggan', 'penjualan-per-pelanggan')
            ->periode($dari, $sampai)
            ->ringkasan([
                'Jumlah Pelanggan' => number_format($baris->count(), 0, ',', '.'),
                'Total Belanja' => Laporan::format($baris->sum('belanja'), 'rupiah'),
            ])
            ->bagian('Rincian per Pelanggan', [
                ['label' => 'Pelanggan', 'key' => 'nama', 'lebar' => 38],
                ['label' => 'Jumlah Transaksi', 'key' => 'transaksi', 'format' => 'angka'],
                ['label' => 'Total Belanja', 'key' => 'belanja', 'format' => 'rupiah'],
                ['label' => 'Rata-rata Belanja', 'key' => 'rata_rata', 'format' => 'rupiah'],
            ], $baris->all(), [
                'nama' => 'TOTAL',
                'transaksi' => $baris->sum('transaksi'),
                'belanja' => $baris->sum('belanja'),
            ])
            ->catatan(
                'Transaksi tanpa pelanggan terdaftar dikelompokkan sebagai "Umum".',
                'Nilai belanja memuat pajak, sesuai yang dibayar pelanggan.',
            );
    }

    /* ========================================================================== KAS */

    private function laporanKas(Request $request): Laporan
    {
        [$dari, $sampai] = $this->rentang($request);

        $type = in_array($request->type, ['in', 'out', 'sale', 'manual_in', 'manual_out', 'return'], true) ? $request->type : null;

        $mutasi = Akuntansi::queryMutasiKas($dari, $sampai, $type)->get();

        $userIds = $mutasi->pluck('user_id')->filter()->unique();
        $users = User::whereIn('id', $userIds)->pluck('name', 'id');

        $kategori = CashTransaction::categories();

        $baris = $mutasi->map(function ($t) use ($users, $kategori) {
            $petugas = $users[$t->user_id] ?? '-';
            $waktu = Carbon::parse($t->created_at)->format('d/m/Y H:i');

            if ($t->source_type === 'sale') {
                $kat = 'Penjualan (' . MetodeBayar::label($t->category) . ')';
                $ket = 'Nota: ' . $t->note . ($t->extra_info ? ' (' . $t->extra_info . ')' : '');
            } elseif ($t->source_type === 'sale_return') {
                $kat = 'Retur Penjualan (Refund)';
                $ket = 'Retur: ' . $t->note . ($t->extra_info ? ' - Alasan: ' . $t->extra_info : '');
            } else {
                $kat = $kategori[$t->category] ?? $t->category;
                $ket = $t->note ?: '-';
            }

            return [
                'tanggal' => $waktu,
                'jenis' => $t->type === 'in' ? 'Masuk' : 'Keluar',
                'kategori' => $kat,
                'keterangan' => $ket,
                'petugas' => $petugas,
                'masuk' => $t->type === 'in' ? (float) $t->amount : 0.0,
                'keluar' => $t->type === 'out' ? (float) $t->amount : 0.0,
            ];
        });

        $ringkasan = [];
        if ($type === 'in' || $type === 'sale' || $type === 'manual_in') {
            $ringkasan['Filter Tipe'] = 'Kas Masuk';
            $ringkasan['Jumlah Transaksi'] = number_format($baris->count(), 0, ',', '.');
            $ringkasan['Total Kas Masuk'] = Laporan::format($baris->sum('masuk'), 'rupiah');
        } elseif ($type === 'out' || $type === 'manual_out' || $type === 'return') {
            $ringkasan['Filter Tipe'] = 'Kas Keluar';
            $ringkasan['Jumlah Transaksi'] = number_format($baris->count(), 0, ',', '.');
            $ringkasan['Total Kas Keluar'] = Laporan::format($baris->sum('keluar'), 'rupiah');
        } else {
            $ringkasan['Total Kas Masuk'] = Laporan::format($baris->sum('masuk'), 'rupiah');
            $ringkasan['Total Kas Keluar'] = Laporan::format($baris->sum('keluar'), 'rupiah');
            $ringkasan['Saldo (Masuk - Keluar)'] = Laporan::format($baris->sum('masuk') - $baris->sum('keluar'), 'rupiah');
        }

        return Laporan::buat('Laporan Kas Masuk & Keluar', 'kas')
            ->periode($dari, $sampai)
            ->ringkasan($ringkasan)
            ->bagian('Rincian Mutasi Kas', [
                ['label' => 'Waktu', 'key' => 'tanggal', 'lebar' => 18],
                ['label' => 'Jenis', 'key' => 'jenis', 'lebar' => 10],
                ['label' => 'Kategori', 'key' => 'kategori', 'lebar' => 26],
                ['label' => 'Keterangan', 'key' => 'keterangan', 'lebar' => 36],
                ['label' => 'Petugas', 'key' => 'petugas', 'lebar' => 18],
                ['label' => 'Masuk', 'key' => 'masuk', 'format' => 'rupiah'],
                ['label' => 'Keluar', 'key' => 'keluar', 'format' => 'rupiah'],
            ], $baris->all(), [
                'tanggal' => 'TOTAL',
                'masuk' => $baris->sum('masuk'),
                'keluar' => $baris->sum('keluar'),
            ])
            ->catatan(
                'Buku ini memuat seluruh mutasi kas: penerimaan penjualan kasir, pengembalian retur, dan transaksi kas operasional.',
                'Kategori Pembelian Barang dan Beli Peralatan TIDAK mengurangi laba: uangnya berubah wujud jadi stok atau peralatan.',
                self::CATATAN_MODAL,
            );
    }

    /* ================================================================ HUTANG USAHA */

    private function laporanHutang(Request $request): Laporan
    {
        $q = trim((string) $request->q);

        $nota = Purchase::with('supplier')
            ->where('sisa_hutang', '>', 0)
            ->when($q !== '', function ($query) use ($q) {
                $query->where(function ($sub) use ($q) {
                    $sub->where('purchase_no', 'like', "%{$q}%")
                        ->orWhere('supplier_invoice_no', 'like', "%{$q}%")
                        ->orWhereHas('supplier', fn ($s) => $s->where('name', 'like', "%{$q}%"));
                });
            })
            ->orderBy('due_date')
            ->orderBy('purchase_date')
            ->get();

        $hariIni = Carbon::today();

        $baris = $nota->map(function (Purchase $p) use ($hariIni) {
            $umur = (int) $p->purchase_date->diffInDays($hariIni);
            $jatuhTempo = $p->due_date;

            $notaLabel = $p->purchase_no;
            if ($p->supplier_invoice_no) {
                $notaLabel .= ' (' . $p->supplier_invoice_no . ')';
            }

            return [
                'nota' => $notaLabel,
                'pemasok' => $p->supplier->name ?? '-',
                'tanggal' => $p->purchase_date->toDateString(),
                'jatuh_tempo' => $jatuhTempo?->toDateString(),
                'status' => $jatuhTempo && $jatuhTempo->lt($hariIni)
                    ? 'LEWAT ' . (int) $jatuhTempo->diffInDays($hariIni) . ' hari'
                    : ($jatuhTempo ? 'Belum jatuh tempo' : 'Tanpa tempo'),
                'umur' => (float) $umur,
                'total' => (float) $p->total,
                'dibayar' => (float) $p->paid_amount,
                'sisa' => (float) $p->sisa_hutang,
            ];
        });

        $lewatTempo = $baris->filter(fn ($b) => str_starts_with($b['status'], 'LEWAT'));

        $ringkasan = [
            'Jumlah Nota Belum Lunas' => number_format($baris->count(), 0, ',', '.'),
            'Total Sisa Hutang' => Laporan::format($baris->sum('sisa'), 'rupiah'),
            'Sudah Lewat Jatuh Tempo' => number_format($lewatTempo->count(), 0, ',', '.') . ' nota ('
                . Laporan::format($lewatTempo->sum('sisa'), 'rupiah') . ')',
        ];

        if ($q !== '') {
            $ringkasan['Pencarian'] = $q;
        }

        return Laporan::buat('Laporan Hutang Usaha', 'hutang-usaha')
            ->periode(now()->toDateString())
            ->ringkasan($ringkasan)
            ->bagian('Rincian Hutang per Nota', [
                ['label' => 'No. Nota', 'key' => 'nota', 'lebar' => 22],
                ['label' => 'Pemasok', 'key' => 'pemasok', 'lebar' => 26],
                ['label' => 'Tgl. Beli', 'key' => 'tanggal', 'format' => 'tanggal', 'lebar' => 14],
                ['label' => 'Jatuh Tempo', 'key' => 'jatuh_tempo', 'format' => 'tanggal', 'lebar' => 14],
                ['label' => 'Status', 'key' => 'status', 'lebar' => 20],
                ['label' => 'Umur (hari)', 'key' => 'umur', 'format' => 'angka'],
                ['label' => 'Total Nota', 'key' => 'total', 'format' => 'rupiah'],
                ['label' => 'Sudah Dibayar', 'key' => 'dibayar', 'format' => 'rupiah'],
                ['label' => 'Sisa Hutang', 'key' => 'sisa', 'format' => 'rupiah'],
            ], $baris->all(), [
                'nota' => 'TOTAL',
                'total' => $baris->sum('total'),
                'dibayar' => $baris->sum('dibayar'),
                'sisa' => $baris->sum('sisa'),
            ])
            ->catatan(
                'Hanya nota yang masih menyisakan hutang yang ditampilkan. Nota lunas tidak muncul.',
                'Umur dihitung dari tanggal pembelian sampai hari ini, bukan dari jatuh tempo.',
                'Total Sisa Hutang di sini sama dengan pos Hutang Usaha di Neraca.',
            );
    }

    /* ====================================================================== PIUTANG */

    private function laporanPiutang(Request $request): Laporan
    {
        $q = trim((string) $request->q);
        $metode = in_array($request->metode, MetodeBayar::kunci(), true) ? $request->metode : null;

        $pesanan = Sale::with(['customer', 'payments'])
            ->where('order_status', 'waiting')
            ->when($q !== '', fn ($query) => $query->where('invoice_no', 'like', "%{$q}%"))
            ->when($metode, fn ($query) => $query->whereHas('payments', fn ($p) => $p->where('method', $metode)))
            ->orderBy('due_date')
            ->orderBy('created_at')
            ->get();

        $hariIni = Carbon::today();

        $baris = $pesanan->map(function (Sale $s) use ($hariIni) {
            $sisa = max((float) $s->total - (float) $s->paid_amount, 0);
            $tempo = $s->due_date ? Carbon::parse($s->due_date) : null;

            $metodeLabel = $s->payments->isEmpty()
                ? 'Belum bayar'
                : $s->payments->map(fn ($b) => MetodeBayar::label($b->method))->unique()->implode(', ');

            return [
                'invoice' => $s->invoice_no,
                'pelanggan' => $s->customer->name ?? 'Umum',
                'tanggal' => $s->created_at->toDateString(),
                'jatuh_tempo' => $tempo?->toDateString(),
                'metode' => $metodeLabel,
                'status' => $tempo && $tempo->lt($hariIni)
                    ? 'LEWAT ' . (int) $tempo->diffInDays($hariIni) . ' hari'
                    : ($tempo ? 'Belum jatuh tempo' : 'Tanpa tempo'),
                'total' => (float) $s->total,
                'dp' => (float) $s->paid_amount,
                'sisa' => $sisa,
            ];
        });

        $ringkasan = [
            'Jumlah Pesanan Belum Lunas' => number_format($baris->count(), 0, ',', '.'),
            'Total Uang Muka Diterima' => Laporan::format($baris->sum('dp'), 'rupiah'),
            'Total Sisa Tagihan' => Laporan::format($baris->sum('sisa'), 'rupiah'),
        ];

        if ($metode) {
            $ringkasan['Filter Metode DP'] = MetodeBayar::label($metode);
        }
        if ($q !== '') {
            $ringkasan['Pencarian'] = $q;
        }

        return Laporan::buat('Laporan Piutang Pesanan', 'piutang')
            ->periode(now()->toDateString())
            ->ringkasan($ringkasan)
            ->bagian('Rincian Pesanan Belum Lunas', [
                ['label' => 'No. Invoice', 'key' => 'invoice', 'lebar' => 18],
                ['label' => 'Pelanggan', 'key' => 'pelanggan', 'lebar' => 24],
                ['label' => 'Tgl. Pesan', 'key' => 'tanggal', 'format' => 'tanggal', 'lebar' => 13],
                ['label' => 'Jatuh Tempo', 'key' => 'jatuh_tempo', 'format' => 'tanggal', 'lebar' => 13],
                ['label' => 'Metode DP', 'key' => 'metode', 'lebar' => 16],
                ['label' => 'Status', 'key' => 'status', 'lebar' => 18],
                ['label' => 'Nilai Pesanan', 'key' => 'total', 'format' => 'rupiah'],
                ['label' => 'Uang Muka', 'key' => 'dp', 'format' => 'rupiah'],
                ['label' => 'Sisa Tagihan', 'key' => 'sisa', 'format' => 'rupiah'],
            ], $baris->all(), [
                'invoice' => 'TOTAL',
                'total' => $baris->sum('total'),
                'dp' => $baris->sum('dp'),
                'sisa' => $baris->sum('sisa'),
            ])
            ->catatan(
                'Sisa tagihan pesanan TIDAK muncul sebagai piutang di Neraca, karena barangnya belum diserahkan sehingga penjualannya belum boleh diakui.',
                'Uang muka yang sudah diterima justru dicatat sebagai KEWAJIBAN di Neraca - toko masih berhutang barang kepada pembelinya.',
                'Stok barang pesanan sudah dipotong supaya tidak terjual dua kali, tapi nilainya tetap dihitung sebagai persediaan.',
            );
    }

    /* ==================================================================== SHIFT KASIR */

    private function laporanShift(Request $request): Laporan
    {
        [$dari, $sampai] = $this->rentang($request);
        $userId = $request->user_id ? (int) $request->user_id : null;
        $shiftId = $request->shift_id ? (int) $request->shift_id : null;
        $status = in_array($request->status, ['open', 'closed'], true) ? $request->status : null;

        // Ambil data shift dengan relasi user dan transaksi beserta item produk (kecuali yang dibatalkan)
        $shifts = CashierShift::with([
            'user',
            'sales' => function ($q) {
                $q->where('order_status', '<>', 'cancelled')
                    ->with(['customer', 'cashier', 'payments', 'items'])
                    ->orderBy('created_at');
            },
        ])
            ->whereDate('opened_at', '>=', $dari)
            ->whereDate('opened_at', '<=', $sampai)
            ->when($userId, fn($q) => $q->where('user_id', $userId))
            ->when($shiftId, fn($q) => $q->where('id', $shiftId))
            ->when($status, fn($q) => $q->where('status', $status))
            ->orderBy('opened_at')
            ->get();

        // 1. Baris Rekapitulasi Shift
        $barisShift = $shifts->map(function (CashierShift $s) {
            $isClosed = $s->status === 'closed';
            $diff = (float) ($s->difference ?? 0);
            $durasi = $s->closed_at
                ? ($s->opened_at->diffInHours($s->closed_at) . ' jam ' . ($s->opened_at->diffInMinutes($s->closed_at) % 60) . ' mnt')
                : 'Aktif';

            $selisihLabel = '-';
            if ($isClosed) {
                if (abs($diff) < 0.01) {
                    $selisihLabel = 'PAS (Rp 0)';
                } elseif ($diff > 0) {
                    $selisihLabel = '+Rp ' . number_format($diff, 0, ',', '.');
                } else {
                    $selisihLabel = '-Rp ' . number_format(abs($diff), 0, ',', '.');
                }
            }

            return [
                'shift_id' => '#' . $s->id,
                'kasir' => $s->user->name ?? 'Kasir #' . $s->user_id,
                'buka' => $s->opened_at->format('d/m/Y H:i'),
                'tutup' => $s->closed_at ? $s->closed_at->format('d/m/Y H:i') : 'Masih Berjalan',
                'durasi' => $durasi,
                'status' => $s->status === 'open' ? 'Aktif' : 'Selesai',
                'modal_awal' => (float) $s->starting_cash,
                'penjualan_tunai' => (float) $s->cash_sales,
                'penjualan_non_tunai' => (float) $s->non_cash_sales,
                'total_penjualan' => (float) ($s->cash_sales + $s->non_cash_sales),
                'fisik_laci' => $s->actual_cash !== null ? (float) $s->actual_cash : 0.0,
                'selisih' => $selisihLabel,
            ];
        });

        // 2. Baris Rincian Seluruh Transaksi per Shift & 3. Baris Rincian Produk
        $barisTransaksi = collect();
        $barisProduk = collect();
        foreach ($shifts as $s) {
            foreach ($s->sales as $sale) {
                $metodes = $sale->payments->isEmpty()
                    ? MetodeBayar::label($sale->payment_method)
                    : $sale->payments->map(fn($p) => MetodeBayar::label($p->method))->unique()->implode(', ');

                $barisTransaksi->push([
                    'shift' => '#' . $s->id,
                    'kasir' => $s->user->name ?? '-',
                    'waktu' => $sale->created_at->format('d/m/Y H:i'),
                    'invoice' => $sale->invoice_no,
                    'pelanggan' => $sale->customer->name ?? 'Umum',
                    'metode' => $metodes,
                    'status' => $this->labelStatus($sale->order_status),
                    'diskon' => (float) $sale->discount,
                    'pajak' => (float) $sale->tax_amount,
                    'total' => (float) $sale->total,
                ]);

                foreach ($sale->items as $item) {
                    $barisProduk->push([
                        'shift' => '#' . $s->id,
                        'kasir' => $s->user->name ?? '-',
                        'invoice' => $sale->invoice_no,
                        'produk' => $item->product_name,
                        'qty' => (float) $item->qty,
                        'satuan' => $item->unit_label ?? 'Pcs',
                        'harga' => (float) $item->price,
                        'subtotal' => (float) $item->subtotal,
                    ]);
                }
            }
        }

        // Ringkasan
        $totalPenjualanTrx = (float) $barisTransaksi->sum('total');
        $totalTunai = (float) $shifts->sum('cash_sales');
        $totalNonTunai = (float) $shifts->sum('non_cash_sales');
        $totalSelisih = (float) $shifts->where('status', 'closed')->sum('difference');

        $ringkasan = [
            'Total Shift' => $shifts->count() . ' shift (' . $shifts->where('status', 'closed')->count() . ' selesai, ' . $shifts->where('status', 'open')->count() . ' aktif)',
            'Total Transaksi Penjualan' => $barisTransaksi->count() . ' transaksi',
            'Total Nilai Penjualan' => Laporan::format($totalPenjualanTrx, 'rupiah'),
            'Penjualan Tunai' => Laporan::format($totalTunai, 'rupiah'),
            'Penjualan Non-Tunai' => Laporan::format($totalNonTunai, 'rupiah'),
            'Total Selisih Kas Laci' => (abs($totalSelisih) < 0.01 ? 'Rp 0 (Pas)' : (($totalSelisih > 0 ? '+' : '-') . Laporan::format(abs($totalSelisih), 'rupiah'))),
        ];

        if ($userId) {
            $kasirUser = User::find($userId);
            if ($kasirUser) {
                $ringkasan['Filter Kasir'] = $kasirUser->name;
            }
        }

        if ($shiftId) {
            $ringkasan['Filter Shift'] = '#' . $shiftId;
        }

        if ($status) {
            $ringkasan['Filter Status Shift'] = $status === 'open' ? 'Open (Aktif)' : 'Closed (Selesai)';
        }

        return Laporan::buat('Laporan Transaksi per Shift', 'laporan-transaksi-shift')
            ->periode($dari, $sampai)
            ->ringkasan($ringkasan)
            ->bagian('Rekapitulasi Shift Kasir', [
                ['label' => 'Shift', 'key' => 'shift_id', 'lebar' => 10],
                ['label' => 'Kasir', 'key' => 'kasir', 'lebar' => 20],
                ['label' => 'Waktu Buka', 'key' => 'buka', 'lebar' => 18],
                ['label' => 'Waktu Tutup', 'key' => 'tutup', 'lebar' => 18],
                ['label' => 'Status', 'key' => 'status', 'lebar' => 12],
                ['label' => 'Modal Awal', 'key' => 'modal_awal', 'format' => 'rupiah'],
                ['label' => 'Tunai', 'key' => 'penjualan_tunai', 'format' => 'rupiah'],
                ['label' => 'Non-Tunai', 'key' => 'penjualan_non_tunai', 'format' => 'rupiah'],
                ['label' => 'Total Penjualan', 'key' => 'total_penjualan', 'format' => 'rupiah'],
                ['label' => 'Fisik Laci', 'key' => 'fisik_laci', 'format' => 'rupiah'],
                ['label' => 'Selisih', 'key' => 'selisih', 'lebar' => 16],
            ], $barisShift->all(), [
                'shift_id' => 'TOTAL',
                'modal_awal' => $barisShift->sum('modal_awal'),
                'penjualan_tunai' => $barisShift->sum('penjualan_tunai'),
                'penjualan_non_tunai' => $barisShift->sum('penjualan_non_tunai'),
                'total_penjualan' => $barisShift->sum('total_penjualan'),
                'fisik_laci' => $barisShift->sum('fisik_laci'),
            ])
            ->bagian('Rincian Transaksi per Shift', [
                ['label' => 'Shift', 'key' => 'shift', 'lebar' => 10],
                ['label' => 'Kasir', 'key' => 'kasir', 'lebar' => 18],
                ['label' => 'Waktu', 'key' => 'waktu', 'lebar' => 18],
                ['label' => 'No. Invoice', 'key' => 'invoice', 'lebar' => 18],
                ['label' => 'Pelanggan', 'key' => 'pelanggan', 'lebar' => 22],
                ['label' => 'Metode Bayar', 'key' => 'metode', 'lebar' => 16],
                ['label' => 'Status', 'key' => 'status', 'lebar' => 14],
                ['label' => 'Diskon', 'key' => 'diskon', 'format' => 'rupiah'],
                ['label' => 'Pajak', 'key' => 'pajak', 'format' => 'rupiah'],
                ['label' => 'Total', 'key' => 'total', 'format' => 'rupiah'],
            ], $barisTransaksi->all(), [
                'shift' => 'TOTAL',
                'diskon' => $barisTransaksi->sum('diskon'),
                'pajak' => $barisTransaksi->sum('pajak'),
                'total' => $barisTransaksi->sum('total'),
            ])
            ->bagian('Rincian Item Produk Terjual per Shift', [
                ['label' => 'Shift', 'key' => 'shift', 'lebar' => 10],
                ['label' => 'Kasir', 'key' => 'kasir', 'lebar' => 18],
                ['label' => 'No. Invoice', 'key' => 'invoice', 'lebar' => 18],
                ['label' => 'Nama Produk / Barang', 'key' => 'produk', 'lebar' => 28],
                ['label' => 'Qty', 'key' => 'qty', 'align' => 'center'],
                ['label' => 'Satuan', 'key' => 'satuan', 'lebar' => 12],
                ['label' => 'Harga Satuan', 'key' => 'harga', 'format' => 'rupiah'],
                ['label' => 'Subtotal', 'key' => 'subtotal', 'format' => 'rupiah'],
            ], $barisProduk->all(), [
                'shift' => 'TOTAL',
                'qty' => $barisProduk->sum('qty'),
                'subtotal' => $barisProduk->sum('subtotal'),
            ])
            ->catatan(
                'Transaksi yang dibatalkan tidak dimasukkan ke dalam laporan transaksi shift dan tidak dihitung ke dalam total.',
                'Selisih kas laci dihitung dari uang fisik laci dikurangi estimasi kas sistem saat penutupan shift.',
            );
    }

    private function laporanTransaksiShift(Request $request): Laporan
    {
        return $this->laporanShift($request);
    }

    private function labelStatus(string $status): string
    {
        return match ($status) {
            'completed' => 'Selesai',
            'waiting' => 'Menunggu',
            'cancelled' => 'Batal',
            default => $status,
        };
    }
}
