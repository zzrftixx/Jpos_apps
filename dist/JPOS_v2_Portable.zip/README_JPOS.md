# JPOS by JaylaTech

> ## 📐 Sebelum menyentuh kode: baca [`BLUEPRINT.md`](BLUEPRINT.md)
>
> **Untuk agen AI dan developer baru.** Blueprint memuat 12 HUKUM yang menjaga kebenaran uang
> dan stok, peta arsitektur, glosarium istilah, skema database lengkap, katalog fitur, model
> akuntansi, angka performa terukur, dan playbook langkah demi langkah.
>
> Membacanya **jauh lebih murah** daripada menyisir 7.800 baris kode — dan mencegah kelas
> kerusakan yang tidak menampakkan diri sebagai galat.
>
> Setiap perubahan wajib dicatat di [`CHANGELOG-TEKNIS.md`](CHANGELOG-TEKNIS.md).



Aplikasi Kasir (POS) berbasis Laravel 13 + SQLite dengan UI Tailwind CSS dan Alpine.js.

**Berjalan penuh tanpa internet.** Seluruh aset UI berada di `public/vendor/` dan aplikasi tidak melakukan satu pun permintaan ke jaringan luar.

## Struktur Menu

- **Dashboard** — ringkasan penjualan hari ini/bulan ini, grafik tren, produk terlaris, peringatan stok menipis
- **Master Data** — Produk (dengan gambar), Kategori, Supplier, Pelanggan
- **Transaksi** — Kasir (POS visual bergambar seperti kasir cafe) & Cetak Barcode, Retur
- **Laporan** — Penjualan, Stok (+riwayat pergerakan stok), Produk Terlaris
- **Manajemen** — User, Role Akses (hak akses menu per role, checkbox)
- **Pengaturan** — Profil Toko, Printer Struk, Printer Barcode, Template Barcode (desain + live preview), Template Struk (desain + live preview), Pajak, Backup & Restore, Database, Tentang

## Cara Menjalankan (Lokal / Server)

Prasyarat: **PHP 8.3+** dengan ekstensi `sqlite3`, `pdo_sqlite`, `gd`/`fileinfo`. Composer opsional (lihat catatan di bawah).

```bash
cd jpos

# 1. WAJIB: regenerate autoload karena composer.json project ini
#    menggunakan "optimize-autoloader": true (classmap statis).
#    Tidak perlu composer install penuh karena tidak ada dependency baru,
#    cukup dump-autoload saja:
composer dump-autoload

# 2. Jalankan migrasi + seeder data awal (role, user demo, kategori, produk contoh)
php artisan migrate --seed

# 3. Buat symlink storage (untuk menampilkan gambar produk & logo toko)
php artisan storage:link

# 4. Jalankan server
php artisan serve
```

Buka `http://localhost:8000` di browser.

### Akun Demo

| Role  | Username | Password |
|-------|----------|----------|
| Admin | admin    | password |
| Kasir | kasir1   | password |

Login sekarang menggunakan **username** (bukan email). Saat admin membuat user baru di menu Manajemen → User, cukup isi Nama, Username, dan Password — email dibuat otomatis di belakang layar (`username@jpos.local`) hanya untuk kebutuhan sistem, tidak perlu diisi manual.

## Cetak Struk & Barcode (Printer Thermal)

- Halaman struk (`/kasir/receipt/{id}`) dan label barcode (`/barcode/print`) memakai CSS `@page` sesuai ukuran yang diatur di **Pengaturan → Printer Struk / Printer Barcode**, lalu memakai `window.print()` bawaan browser.
- Untuk mencetak ke printer thermal (58mm/80mm) atau printer label barcode: pilih printer tersebut pada dialog cetak browser (Chrome/Edge disarankan), dan set margin ke "None"/"Tanpa margin" agar hasilnya rapi.
- Aktifkan "Cetak otomatis saat struk dibuka" di Pengaturan → Printer Struk jika ingin struk langsung memunculkan dialog print begitu transaksi selesai.

## Fitur Pembayaran DP & Waiting List Order

- Di halaman **Kasir**, centang **"Jadikan Pesanan / Waiting List (bayar DP dulu)"** sebelum klik bayar. Stok tetap langsung dikurangi (direservasi) agar tidak terjual ke pelanggan lain, tapi transaksi dicatat sebagai **Menunggu DP** dengan sisa tagihan.
- Buka menu **Transaksi → Pesanan / Waiting List** untuk melihat semua pesanan yang masih DP, melunasi (sekaligus atau bertahap/cicil), mencetak bukti DP, atau membatalkan pesanan (stok otomatis dikembalikan).
- Saat pelunasan membuat total bayar &ge; total tagihan, status pesanan otomatis berubah menjadi **Lunas/Selesai**.
- **Laporan Penjualan** bisa difilter berdasarkan status pesanan (Lunas/Menunggu DP/Dibatalkan); ringkasan pendapatan hanya menghitung transaksi yang sudah Lunas agar tidak overstate dari DP yang belum lunas.
- Retur hanya bisa dilakukan pada transaksi yang statusnya sudah **Lunas/Selesai**.

⚠️ Karena fitur ini menambah kolom baru di tabel `sales` (`order_status`, `due_date`, `note`), jalankan lagi `php artisan migrate` (data lama aman, tidak perlu `--seed` ulang kecuali databasenya baru).

- **Database**: SQLite (`database/database.sqlite`), tidak perlu setup MySQL.
- **Aset lokal**: Tailwind CSS, Alpine.js, Chart.js, JsBarcode, dan Iconify semuanya berada di `public/vendor/`.
  Lihat `public/vendor/README.md` untuk cara membangun ulang `jpos.css` bila ada class Tailwind baru dipakai di Blade.
- **Role Akses**: setiap role punya daftar menu yang diizinkan (kolom `permissions` JSON di tabel `roles`). Role `admin` selalu memiliki akses penuh.
- **Backup & Restore**: backup disimpan di `storage/app/private/backups/` memakai `VACUUM INTO`
  sehingga isinya konsisten walau database sedang dipakai (mode WAL). Restore memeriksa file
  yang diunggah lebih dulu (header SQLite, integrity check, keberadaan tabel inti JPOS) dan
  selalu membuat salinan `pre-restore` sebelum mengganti apa pun.

  Riwayatnya **terurut dari yang terbaru**, tiap baris diberi keterangan jenis (Manual,
  Otomatis harian, Sebelum pembaruan, Sebelum hapus data), dan bisa dihapus satu-satu untuk
  merapikan. Backup terakhir yang tersisa sengaja tidak bisa dihapus. Aplikasi juga membuat
  **salinan otomatis sekali sehari** saat pertama dibuka hari itu. Yang disimpan 30 terbaru,
  ditambah 5 salinan pengaman terakhir yang selalu dipertahankan.

  Karena berkas backup sebesar databasenya, isi folder juga dibatasi **2 GB** supaya disk
  komputer kasir tidak penuh diam-diam pada toko yang datanya sudah besar. Sepuluh salinan
  terbaru dan seluruh salinan pengaman tetap disimpan berapa pun ukurannya.

## Struktur Folder Penting

```
app/Http/Controllers/   -> semua controller (Produk, Kasir, Setting, dll)
app/Http/Middleware/CheckMenuAccess.php  -> middleware hak akses menu
app/Models/              -> Eloquent models
database/migrations/     -> struktur tabel
database/seeders/        -> data awal (role, user, kategori, produk contoh)
resources/views/         -> semua tampilan Blade
routes/web.php           -> semua route aplikasi
```

## Membuat Paket untuk Client

```powershell
.\build-exe.ps1
```

Menghasilkan dua berkas di `dist/`:

| Berkas | Untuk apa |
|---|---|
| `JPOS_v2_Portable.zip` | Instalasi baru yang bersih. Database dibuat sendiri saat pertama dijalankan. |
| `JPOS_Update_<versi>.zip` | Pembaruan untuk client yang sudah berjalan. |

**Paket update tidak pernah menyentuh `database/` maupun `storage/app/`.** Data penjualan,
gambar produk, dan pengaturan toko client tetap utuh. `UPDATE.bat` juga membuat cadangan
database lebih dulu, dan membatalkan seluruh proses kalau cadangan itu gagal dibuat.

Build script berhenti dengan kesalahan kalau menemukan berkas `.sqlite` ikut terbawa ke
dalam paket — pengaman terhadap kesalahan yang dulu mengirim database developer ke client.

## Cara Client Memasang Pembaruan

1. Ekstrak `JPOS_Update_<versi>.zip`.
2. Pindahkan isinya (`UPDATE.bat` dan folder `_baru`) ke **dalam folder JPOS** yang sudah ada.
3. Klik dua kali `UPDATE.bat`, tunggu sampai selesai.

Kalau pembaruan gagal di tengah jalan, aplikasi **mengembalikan sendiri** database ke keadaan
sebelum pembaruan, lalu menolak menyala sambil menampilkan sebabnya. Itu disengaja: struktur
lama dengan aplikasi baru akan salah mencatat di mana-mana, dan salah yang diam jauh lebih
mahal daripada berhenti dengan jelas. Data Anda tetap utuh — catat pesan yang muncul di layar
lalu hubungi pembuat aplikasi.

Salinan sebelum pembaruan juga tetap tersimpan di `storage\app\private\backups\` dengan nama
berawalan `pre-update-`, dan bisa dipulihkan lewat menu **Pengaturan → Backup & Restore**.

## Kalau Hasil Cetak Struk Miring / Tidak Rapi

Ini penyebab yang paling sering, dan paling tidak terduga: **printer termal tidak mencetak
sampai tepi kertas.** Kepala cetaknya lebih sempit dari rolnya:

| Kertas | Yang benar-benar tercetak |
|---|---|
| Rol 58 mm | **48 mm** |
| Rol 80 mm | **72 mm** |

Kalau struk ditata selebar kertas, printer akan **mengecilkan seluruh halaman** supaya muat —
dan itulah yang terlihat sebagai tulisan miring dan tidak di tengah, walaupun pratinjau di
layar rata tengah.

Cara memastikannya benar:

1. Buka **Pengaturan → Printer Struk**.
2. Periksa kolom **Lebar Cetak**. Wajar kalau angkanya lebih kecil dari lebar kertas.
3. Klik **Simpan**, lalu **Uji Cetak**.
4. Cetak lembar ujinya, lalu periksa tiga hal:
   - kotak "GARIS TEPI" harus utuh keempat sisinya
   - batang hitam harus penuh dari tepi kiri sampai kanan
   - penggarisnya, kalau diukur dengan penggaris sungguhan, harus selebar angka Lebar Cetak
5. Kalau ada yang terpotong, **turunkan** angka Lebar Cetak lalu ulangi.

> Saat dialog cetak muncul, pastikan **Skala = 100% / Default** (jangan "Fit to page") dan
> matikan "Headers and footers". Kalau skalanya bukan 100%, hasilnya pasti mengecil berapa
> pun angka yang diisi.

## Kalau Cetak Label Barcode Menghabiskan Kertas

Buka **Pengaturan → Printer Barcode** dan periksa **Label Dicetak Ke**:

- **Printer label khusus** — satu label per lembar. Pilih ini kalau punya printer label.
- **Printer struk 58/80 mm** — label dicetak menyambung ke bawah dengan garis potong.

Kalau label dikirim ke printer struk tapi modenya masih "printer label", printer struk tidak
mengenal ukuran lembarnya dan **setiap label memakan satu umpan kertas penuh** — beberapa
label saja bisa menghabiskan segulung kertas.

Halaman cetak juga menampilkan **jumlah total label sebelum tombol ditekan**, dan membatasi
maksimal 300 label sekali cetak supaya angka yang salah ketik tidak sempat menghabiskan kertas.

## Pindai Barcode di Kasir

Alat pindai barcode bekerja seperti papan ketik. JPos menangkapnya dari **seluruh layar** —
tidak perlu mengklik kolom pencarian dulu, dan hasil pindaian tidak akan masuk ke kolom
nominal bayar walaupun kolom itu sedang aktif.

- **Kode tidak terdaftar** → muncul pesan yang menyebut kodenya, dan kodenya ditinggal di
  kolom pencarian supaya bisa langsung dicari lewat nama.
- **Barang tanpa barcode** → ketik namanya lalu Enter. Kalau tinggal satu barang yang cocok,
  barang itu langsung masuk keranjang; kalau lebih dari satu, JPos memberi tahu berapa yang
  cocok dan Anda memilih sendiri.
- **Barcode per satuan** → di Master Produk, tiap satuan tambahan bisa diberi barcode sendiri.
  Kalau diisi, memindai label satuan itu **langsung memilih satuannya** — kasir tidak perlu
  memilih apa pun. Kalau dikosongkan, satuan itu tetap ikut barcode produknya seperti biasa.

## Kalau Lupa Password dan Tidak Bisa Masuk

Halaman login JPOS **sengaja tidak punya tombol "lupa password"**. Tombol seperti itu berdiri
di depan pintu dan bisa ditekan siapa saja yang membuka aplikasi — termasuk orang yang tidak
berhak melihat laporan laba toko Anda.

Jalan pulangnya ada di berkas, bukan di halaman:

1. Tutup jendela JPOS kalau masih terbuka.
2. Di folder JPOS, klik dua kali **`PULIHKAN-LOGIN.bat`**.
3. Ketik `PULIHKAN` lalu Enter.
4. Masuk lagi dengan username `admin` dan password `password`.
5. **Segera ganti passwordnya** di Manajemen → User.

Yang perlu diketahui:

- **Tidak ada data penjualan yang dihapus atau diubah.** Salinan pengaman database dibuat
  otomatis sebelum apa pun terjadi.
- Alat ini hanya bisa dijalankan orang yang memegang komputer toko ini. Lewat jaringan, ia
  tidak terjangkau sama sekali.
- **Setiap pemulihan meninggalkan jejak.** Peringatan merah muncul di setiap halaman sampai
  ditutup manual, dan riwayat lengkapnya tersimpan permanen di
  `storage\logs\pemulihan-login.log` — berkas yang tidak bisa dihapus dari dalam aplikasi.
  Jadi kalau suatu saat Anda melihat peringatan itu padahal bukan Anda yang melakukannya,
  artinya ada orang lain yang sempat memegang komputer toko Anda.

Halaman login juga menahan tebakan beruntun: setelah 5 percobaan gagal, login untuk akun itu
dijeda 60 detik.

## Kalau Aplikasi Bermasalah

- **Tidak mau menyala / pesan error saat start** — buka `storage\logs\launcher.log`.
  Berkas ini juga bisa dibuka lewat klik kanan ikon JPOS di system tray → *Lihat Log Teknis*.
- **Halaman terlihat berantakan tanpa warna** — kemungkinan `public\vendor\jpos.css` tidak
  ikut tersalin. Sebagai jalan pintas, set `JPOS_TAILWIND_MODE=play` di `.env`; tampilan
  kembali normal tanpa perlu build ulang.
- **Error PHP** — lihat `storage\logs\laravel.log` dan `storage\logs\php-error.log`.
