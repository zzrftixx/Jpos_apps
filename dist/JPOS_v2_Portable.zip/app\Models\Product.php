<?php

namespace App\Models;

use App\Support\Angka;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Product extends Model
{
    protected $fillable = [
        'name', 'type', 'sku', 'barcode', 'category_id', 'supplier_id', 'unit',
        'multi_unit_enabled', 'hpp_calc_enabled',
        'cost_price', 'sell_price', 'reseller_price', 'grosir_price',
        'wholesale_price', 'wholesale_min_qty',
        'stock', 'track_stock', 'min_stock', 'is_taxable',
        'image', 'description', 'is_active',
    ];

    protected $casts = [
        'is_taxable' => 'boolean',
        'is_active' => 'boolean',
        'track_stock' => 'boolean',
        'multi_unit_enabled' => 'boolean',
        'hpp_calc_enabled' => 'boolean',
        'cost_price' => 'decimal:2',
        'sell_price' => 'decimal:2',
        'reseller_price' => 'decimal:2',
        'grosir_price' => 'decimal:2',
        'wholesale_price' => 'decimal:2',
        // Sengaja 'float', bukan 'decimal:4'. Stok boleh pecahan sejak barang timbangan
        // bisa dijual per Kg atau per Gram; cast decimal menghasilkan STRING ("9.6000")
        // yang lalu ikut ke katalog JSON dan menyusahkan perhitungan di sisi kasir.
        'stock' => 'float',
        'min_stock' => 'float',
    ];

    /**
     * image_url adalah accessor, jadi TIDAK ikut saat model diubah ke JSON kecuali
     * didaftarkan di sini. Tanpa ini, tombol Edit di Master Produk mengirim data produk
     * ke form tanpa image_url, sehingga kotak pratinjau gambar selalu kosong walaupun
     * produknya punya gambar.
     */
    protected $appends = ['image_url'];

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class);
    }

    public function stockMovements(): HasMany
    {
        return $this->hasMany(StockMovement::class);
    }

    /**
     * Satuan tambahan, SELALU terurut dari yang paling dekat ke satuan dasar.
     *
     * Urutannya load-bearing, bukan kosmetik: rantai satuan dibaca dan ditulis mengikuti
     * urutan ini, jadi tanpa orderBy hasil pelipatan rasio bisa berbeda tiap kali data
     * dibaca ulang.
     */
    public function units(): HasMany
    {
        return $this->hasMany(ProductUnit::class)->orderBy('sort_order')->orderBy('id');
    }

    public static function resolveAppBasePath(): string
    {
        if (app()->runningInConsole() && ! app()->runningUnitTests()) {
            return '';
        }

        if (! app()->bound('request')) {
            return '';
        }

        $base = rtrim((string) request()->getBasePath(), '/');

        return $base === '/' ? '' : $base;
    }

    public function rawMediaPath(): string
    {
        return $this->image ? '/media/' . ltrim($this->image, '/') : '/images/no-image.svg';
    }

    public function getImageUrlAttribute(): string
    {
        return static::resolveAppBasePath() . $this->rawMediaPath();
    }

    /**
     * Menambah atau mengurangi stok, lalu mengembalikan stok setelahnya.
     *
     * Sengaja TIDAK memakai increment()/decrement(). Keduanya menghasilkan SQL
     * `SET stock = stock + ?` yang dijalankan langsung oleh SQLite tanpa pembulatan, dan
     * setelah puluhan transaksi pecahan galat float menumpuk menjadi sisa seperti
     * 9.599999999999999 - yang lalu tampil apa adanya di layar kasir dan tersimpan
     * selamanya. Membulatkan di sini membuat stok selalu bersih.
     *
     * Pemanggilnya SELALU sudah memegang lockForUpdate() atas produk ini, jadi membaca
     * lalu menulis kembali di sini aman dari balapan.
     */
    public function ubahStok(float $selisih): float
    {
        $this->stock = Angka::bulat($this->stock + $selisih);
        $this->save();

        return $this->stock;
    }

    public function isLowStock(): bool
    {
        return $this->tracksStock() && $this->stock <= $this->min_stock;
    }

    public function isJasa(): bool
    {
        return $this->type === 'jasa';
    }

    /**
     * Menentukan apakah produk ini melacak/mengelola stok fisik atau tanpa stok.
     * Pada mode Kasir F&B, perilaku stok dipengaruhi juga oleh Pengaturan Stok Menu F&B.
     */
    public function tracksStock(?string $contextLayout = null, ?string $fnbMode = null): bool
    {
        if ($this->isJasa()) {
            return false;
        }

        $layout = $contextLayout ?? Setting::kasirLayout();
        if ($layout === 'fnb') {
            $resolvedFnbMode = $fnbMode ?? Setting::fnbStockMode();
            if ($resolvedFnbMode === 'all_nostock') {
                return false;
            }
            if ($resolvedFnbMode === 'all_stock') {
                return true;
            }
        }

        return (bool) ($this->track_stock ?? true);
    }

    public function isTanpaStok(?string $contextLayout = null): bool
    {
        return !$this->tracksStock($contextLayout);
    }

    /**
     * @param array<string,bool>|null $petaSatuanTimbangan Nama satuan -> boleh qty pecahan.
     *        Dilewatkan dari pemanggil yang membacanya sekali untuk seluruh katalog; kalau
     *        tidak diberikan, satu query dijalankan di sini. Untuk katalog 2.000 produk,
     *        selisihnya 1 query lawan 2.000.
     */
    public function promotionItems(): HasMany
    {
        return $this->hasMany(PromotionItem::class);
    }

    public function toCartArray(?array $petaSatuanTimbangan = null, ?array $petaLokasiRak = null, ?array $petaPromo = null, ?string $contextLayout = null, ?string $fnbMode = null): array
    {
        $bolehPecahan = $petaSatuanTimbangan !== null
            ? ($petaSatuanTimbangan[$this->unit] ?? false)
            : (bool) Unit::where('name', $this->unit)->value('is_weighable');

        // Sama alasannya dengan peta satuan timbangan di atas: dibaca sekali untuk seluruh
        // katalog, bukan sekali per produk. Untuk pemanggilan satuan (mis. hasil pindai
        // barcode) peta boleh dikosongkan dan lokasinya dicari langsung.
        $lokasiRak = $petaLokasiRak !== null
            ? ($petaLokasiRak[$this->id] ?? null)
            : $this->lokasiRak();

        $promo = $petaPromo !== null ? ($petaPromo[$this->id] ?? null) : null;
        $promoPrice = null;
        $promoName = null;
        $promoBarcode = null;
        if ($promo) {
            $promoPrice = (float) (is_array($promo) ? ($promo['promo_price'] ?? 0) : ($promo->promo_price ?? 0));
            $promoName = (string) (is_array($promo) ? ($promo['promo_name'] ?? '') : ($promo->promo_name ?? ''));
            $promoBarcode = (string) (is_array($promo) ? ($promo['promo_barcode'] ?? '') : ($promo->promo_barcode ?? ''));
        }

        return [
            'id' => $this->id,
            'name' => $this->name,
            'type' => $this->type,
            'sku' => $this->sku,
            'barcode' => $this->barcode,
            'sell_price' => (float) $this->sell_price,
            'reseller_price' => $this->reseller_price !== null ? (float) $this->reseller_price : null,
            'grosir_price' => $this->grosir_price !== null ? (float) $this->grosir_price : null,
            'wholesale_price' => $this->wholesale_price !== null ? (float) $this->wholesale_price : null,
            'wholesale_min_qty' => $this->wholesale_min_qty,
            'unit' => $this->unit,
            // Satuan dasar mengambil izin pecahan dari tabel units ("Kg" memang satuan
            // timbangan di mana pun ia dipakai); satuan tambahan menentukannya per produk.
            'is_weighable' => $bolehPecahan,
            // ->all() (bukan ->values()) supaya isinya benar-benar array biasa sampai ke
            // dalam. Sebagai Collection, nilai ini tidak selamat melewati serialisasi
            // cache dan berubah menjadi __PHP_Incomplete_Class saat dibaca kembali.
            'additional_units' => $this->units->map(fn($pu) => $pu->toCartArray())->values()->all(),
            'stock' => $this->stock,
            'track_stock' => (bool) ($this->track_stock ?? true),
            'tracks_stock' => $this->tracksStock($contextLayout, $fnbMode),
            'category_id' => $this->category_id,
            'category_name' => $this->category?->name,
            'category' => $this->category?->name,
            'image' => $this->image,
            'image_url' => $this->image_url,
            'is_taxable' => $this->is_taxable,
            // Ditanam ke katalog supaya kasir bisa menjawab "ada di mana?" tanpa mencari ke
            // belakang. null berarti produk itu belum ditaruh di planogram mana pun.
            'rack_location' => $lokasiRak,
            'promo_active' => $promo !== null,
            'promo_price' => $promoPrice,
            'promo_name' => $promoName,
            'promo_barcode' => $promoBarcode,
        ];
    }

    public function rackSlot(): HasOne
    {
        return $this->hasOne(RackSlot::class);
    }

    /** Label lokasi rak produk ini, mis. "Rak A 2-3". null kalau belum ditaruh di rak mana pun. */
    public function lokasiRak(): ?string
    {
        $slot = $this->relationLoaded('rackSlot') ? $this->rackSlot : RackSlot::where('product_id', $this->id)->first();

        return $slot?->label();
    }
}
