<?php

namespace App\Http\Controllers\Concerns;

use App\Models\Product;
use App\Models\Unit;

trait ResolvesUnitPricing
{
    /** @var array<string,bool>|null Peta nama satuan -> boleh pecahan, dihidrasi sekali. */
    private ?array $petaSatuanTimbangan = null;

    /** @var array<int,float>|null Peta id produk -> harga promo aktif terendah hari ini, dihidrasi sekali per permintaan (B1). */
    private ?array $petaHargaPromoAktif = null;

    /**
     * Tentukan konversi-ke-satuan-dasar, label satuan, harga (sudah memperhitungkan harga
     * grosir per satuan itu sendiri), dan apakah satuannya boleh dijual dengan qty pecahan.
     *
     * unit_type: 'base' (satuan dasar produk) atau 'unit_<id>' (salah satu ProductUnit
     * milik produk ini, mis. DUS/LUSIN yang dikonfigurasi di Master Data > Produk).
     *
     * Boleh-tidaknya qty pecahan datang dari dua tempat yang berbeda, dan itu disengaja:
     *
     *   - satuan DASAR mengambilnya dari tabel `units`, karena "Kg" memang satuan timbangan
     *     di mana pun ia dipakai;
     *   - satuan TAMBAHAN mengambilnya dari baris product_units, karena "Kg" pada Gula yang
     *     ditimbang boleh pecahan sementara "Kg" pada produk lain yang dijual per karung
     *     tidak.
     */
    protected function resolveUnitPricing(Product $product, ?string $unitType, float $qty, ?string $customerType = 'UMUM'): array
    {
        $unitType = $unitType ?: 'base';
        $tipe = strtoupper(trim((string) $customerType) ?: 'UMUM');

        if ($unitType === 'base') {
            if ($tipe === 'RESELLER' && $product->reseller_price !== null && (float) $product->reseller_price > 0) {
                $price = (float) $product->reseller_price;
            } elseif ($tipe === 'GROSIR' && $product->grosir_price !== null && (float) $product->grosir_price > 0) {
                $price = (float) $product->grosir_price;
            } elseif ($product->wholesale_price !== null && $product->wholesale_min_qty !== null && $qty >= $product->wholesale_min_qty) {
                $price = (float) $product->wholesale_price;
            } else {
                $price = (float) $product->sell_price;
            }

            $promoPrice = $this->getActivePromoPrice($product->id);
            if ($promoPrice !== null) {
                $price = min($price, $promoPrice);
            }

            return [
                'conversion' => 1.0,
                'label' => null,
                'price' => $price,
                'is_weighable' => $this->satuanDasarBolehPecahan($product->unit),
            ];
        }

        if (str_starts_with($unitType, 'unit_')) {
            $productUnitId = (int) substr($unitType, 5);
            $productUnit = $product->units->firstWhere('id', $productUnitId);

            if (!$productUnit) {
                abort(422, "Satuan yang dipilih untuk {$product->name} tidak ditemukan atau sudah dihapus.");
            }

            if ($tipe === 'RESELLER' && $productUnit->reseller_price !== null && (float) $productUnit->reseller_price > 0) {
                $price = (float) $productUnit->reseller_price;
            } elseif ($tipe === 'GROSIR' && $productUnit->grosir_price !== null && (float) $productUnit->grosir_price > 0) {
                $price = (float) $productUnit->grosir_price;
            } elseif ($productUnit->wholesale_price !== null && $productUnit->wholesale_min_qty !== null && $qty >= $productUnit->wholesale_min_qty) {
                $price = (float) $productUnit->wholesale_price;
            } else {
                $price = (float) $productUnit->price;
            }

            return [
                'conversion' => (float) $productUnit->conversion,
                'label' => $productUnit->unit->name,
                'price' => $price,
                'is_weighable' => (bool) $productUnit->allow_decimal,
            ];
        }

        abort(422, 'Tipe satuan tidak valid.');
    }

    /**
     * Menolak qty pecahan untuk satuan yang tidak ditimbang.
     *
     * Setengah Dus tidak ada wujudnya, dan kalau diterima, stok toko akan berisi angka yang
     * tidak mungkin dicocokkan dengan barang di rak. Aturannya tidak bisa ditaruh di
     * validator permintaan karena boleh-tidaknya bergantung pada satuan yang dipilih di
     * baris itu, dan itu baru diketahui setelah produknya dibaca dari database.
     */
    protected function pastikanQtyBolehPecahan(Product $product, float $qty, bool $bolehPecahan, ?string $labelSatuan): void
    {
        if ($bolehPecahan || floor($qty) == $qty) {
            return;
        }

        $satuan = $labelSatuan ?: $product->unit;

        abort(422, "Qty {$product->name} ({$satuan}) harus bilangan bulat. Satuan ini bukan satuan timbangan - centang \"Satuan timbangan\" di Master Data > Satuan kalau memang dijual per berat.");
    }

    /**
     * Petanya dibaca SEKALI per permintaan, bukan sekali per baris keranjang.
     *
     * Pemanggilnya berada di dalam loop checkout yang sudah memegang kunci baris produk,
     * jadi satu query per baris di sini berarti keranjang 20 baris menahan database 20 kali
     * lebih lama daripada seharusnya - di server yang cuma melayani satu permintaan pada
     * satu waktu.
     */
    private function satuanDasarBolehPecahan(?string $namaSatuan): bool
    {
        if ($this->petaSatuanTimbangan === null) {
            $this->petaSatuanTimbangan = Unit::pluck('is_weighable', 'name')
                ->map(fn ($v) => (bool) $v)
                ->all();
        }

        return $this->petaSatuanTimbangan[$namaSatuan] ?? false;
    }

    /**
     * Memeriksa apakah ada harga promosi aktif untuk produk ini pada hari ini.
     * Dihidrasi sekali per permintaan agar loop checkout di dalam transaksi tidak menjalankan N+1 query (B1).
     */
    protected function getActivePromoPrice(int $productId): ?float
    {
        if ($this->petaHargaPromoAktif === null) {
            $today = now()->toDateString();

            $this->petaHargaPromoAktif = \Illuminate\Support\Facades\DB::table('promotion_items')
                ->join('promotions', 'promotions.id', '=', 'promotion_items.promotion_id')
                ->where('promotions.is_active', true)
                ->where(function ($q) use ($today) {
                    $q->whereNull('promotions.start_date')->orWhereDate('promotions.start_date', '<=', $today);
                })
                ->where(function ($q) use ($today) {
                    $q->whereNull('promotions.end_date')->orWhereDate('promotions.end_date', '>=', $today);
                })
                ->selectRaw('promotion_items.product_id, MIN(promotion_items.promo_price) as min_promo_price')
                ->groupBy('promotion_items.product_id')
                ->pluck('min_promo_price', 'product_id')
                ->map(fn ($v) => (float) $v)
                ->all();
        }

        return $this->petaHargaPromoAktif[$productId] ?? null;
    }
}
