@echo off
REM ===================================================================
REM  JPOS - Pemulihan Login
REM
REM  Dipakai kalau pemilik toko lupa password dan tidak bisa masuk.
REM  Password akun admin dikembalikan ke bawaan: password
REM
REM  TIDAK ADA data penjualan yang dihapus atau diubah.
REM  Salinan pengaman database dibuat lebih dulu secara otomatis.
REM
REM  Setiap pemulihan dicatat di storage\logs\pemulihan-login.log dan
REM  ditampilkan sebagai peringatan di dalam aplikasi.
REM ===================================================================
setlocal
cd /d "%~dp0"
echo.
echo  Tutup dulu jendela JPOS kalau masih terbuka, lalu tekan sembarang tombol.
pause >nul
php\php.exe artisan jpos:pulihkan-login
echo.
pause
endlocal
