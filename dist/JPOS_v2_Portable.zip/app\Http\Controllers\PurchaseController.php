<?php

namespace App\Http\Controllers;

use App\Models\CashTransaction;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\PurchaseItem;
use App\Models\PurchasePayment;
use App\Models\Setting;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Support\Angka;
use App\Support\ProductCatalog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Pembelian barang dagangan.
 *
 * Menutup lubang paling mendasar di pembukuan JPos: sebelumnya stok bertambah tanpa jejak
 * uang sama sekali. Setiap pembelian di sini selalu menggerakkan TIGA hal sekaligus, dalam
 * satu transaksi database:
 *
 *   1. STOK bertambah, beserta catatan mutasinya
 *   2. HARGA MODAL produk diperbarui, termasuk bagian biaya kirimnya
 *   3. UANG tercatat - keluar dari kas kalau tunai, atau menjadi hutang kalau belum dibayar
 *
 * Kalau salah satu tidak ikut, neraca berhenti seimbang dan penyebabnya sulit dilacak
 * berbulan-bulan kemudian.
 */
class PurchaseController extends Controller
{
    public function index(Request $request)
    {
        $purchases = Purchase::with(['supplier', 'items', 'payments.user', 'user'])
            ->when($request->q && $request->tab !== 'rekap_produk', fn ($q) => $q->where(function ($sub) use ($request) {
                $sub->where('purchase_no', 'like', "%{$request->q}%")
                    ->orWhere('supplier_invoice_no', 'like', "%{$request->q}%")
                    ->orWhereHas('supplier', fn ($s) => $s->where('name', 'like', "%{$request->q}%"));
            }))
            ->when($request->supplier_id && $request->tab !== 'rekap_produk', fn ($q) => $q->where('supplier_id', $request->supplier_id))
            ->when($request->periode === 'hari_ini' && $request->tab !== 'rekap_produk', fn ($q) => $q->whereDate('purchase_date', today()))
            ->when($request->periode === '7_hari' && $request->tab !== 'rekap_produk', fn ($q) => $q->where('purchase_date', '>=', now()->subDays(7)->startOfDay()))
            ->when($request->periode === 'bulan_ini' && $request->tab !== 'rekap_produk', fn ($q) => $q->whereMonth('purchase_date', now()->month)->whereYear('purchase_date', now()->year))
            ->when($request->status === 'hutang', fn ($q) => $q->where('sisa_hutang', '>', 0))
            ->when($request->status === 'lunas', fn ($q) => $q->where('sisa_hutang', '<=', 0))
            ->when($request->status === 'tempo', fn ($q) => $q->where('sisa_hutang', '>', 0)->whereNotNull('due_date')->whereDate('due_date', '<', now()))
            ->orderByDesc('purchase_date')
            ->orderByDesc('id')
            ->paginate(15)
            ->withQueryString();

        $ringkasan = (object) [
            'total_bulan_ini' => Angka::bulat(Purchase::whereMonth('purchase_date', now()->month)->whereYear('purchase_date', now()->year)->sum('total')),
            'total_hutang' => Angka::bulat(Purchase::where('sisa_hutang', '>', 0)->sum('sisa_hutang')),
            'jumlah_nota_hutang' => Purchase::where('sisa_hutang', '>', 0)->count(),
            'jatuh_tempo' => Purchase::where('sisa_hutang', '>', 0)
                ->whereNotNull('due_date')
                ->whereDate('due_date', '<', now())
                ->count(),
        ];

        // Filter rentang tanggal khusus Rekap Barang Masuk / Kulakan
        $rekapPeriode = $request->input('periode', 'bulan_ini');
        $rekapFrom = null;
        $rekapTo = null;

        if ($rekapPeriode === 'hari_ini') {
            $rekapFrom = today()->toDateString();
            $rekapTo = today()->toDateString();
        } elseif ($rekapPeriode === '7_hari') {
            $rekapFrom = now()->subDays(7)->toDateString();
            $rekapTo = today()->toDateString();
        } elseif ($rekapPeriode === 'bulan_ini' || empty($rekapPeriode)) {
            $rekapFrom = now()->startOfMonth()->toDateString();
            $rekapTo = now()->endOfMonth()->toDateString();
        } elseif ($rekapPeriode === 'bulan_lalu') {
            $rekapFrom = now()->subMonth()->startOfMonth()->toDateString();
            $rekapTo = now()->subMonth()->endOfMonth()->toDateString();
        } elseif ($rekapPeriode === 'custom' || ($request->filled('from') && $request->filled('to'))) {
            $rekapFrom = $request->from;
            $rekapTo = $request->to;
            $rekapPeriode = 'custom';
        } elseif ($rekapPeriode === 'semua') {
            $rekapFrom = null;
            $rekapTo = null;
        }

        // Query dasar Rekapitulasi Pembelian per Produk (tidak berkurang oleh penjualan)
        $baseRekapQuery = DB::table('purchase_items')
            ->join('purchases', 'purchases.id', '=', 'purchase_items.purchase_id')
            ->leftJoin('products', 'products.id', '=', 'purchase_items.product_id')
            ->leftJoin('suppliers', 'suppliers.id', '=', 'purchases.supplier_id');

        if ($rekapFrom && $rekapTo) {
            $baseRekapQuery->whereDate('purchases.purchase_date', '>=', $rekapFrom)
                           ->whereDate('purchases.purchase_date', '<=', $rekapTo);
        } elseif ($rekapFrom) {
            $baseRekapQuery->whereDate('purchases.purchase_date', '>=', $rekapFrom);
        } elseif ($rekapTo) {
            $baseRekapQuery->whereDate('purchases.purchase_date', '<=', $rekapTo);
        }

        if ($request->filled('supplier_id')) {
            $baseRekapQuery->where('purchases.supplier_id', $request->supplier_id);
        }

        if ($request->filled('q')) {
            $qRekap = $request->q;
            $baseRekapQuery->where(function ($w) use ($qRekap) {
                $w->where('purchase_items.product_name', 'like', "%{$qRekap}%")
                  ->orWhere('products.name', 'like', "%{$qRekap}%")
                  ->orWhere('products.barcode', 'like', "%{$qRekap}%")
                  ->orWhere('products.sku', 'like', "%{$qRekap}%");
            });
        }

        // Ringkasan akumulasi seluruh produk yang dibeli
        $summaryQuery = clone $baseRekapQuery;
        $rekapRingkasan = (object) [
            'total_nominal' => (float) ($summaryQuery->sum('purchase_items.subtotal') ?? 0),
            'total_base_qty' => (float) ($summaryQuery->sum(DB::raw('purchase_items.qty * COALESCE(purchase_items.unit_conversion, 1)')) ?? 0),
            'total_produk' => (int) ($summaryQuery->distinct('purchase_items.product_id')->count('purchase_items.product_id')),
            'total_faktur' => (int) ($summaryQuery->distinct('purchases.id')->count('purchases.id')),
        ];

        // Paginated items terindeks per produk
        $rekapQuery = clone $baseRekapQuery;
        $rekapProduk = $rekapQuery
            ->select(
                'purchase_items.product_id',
                DB::raw('COALESCE(products.name, purchase_items.product_name) as nama_produk'),
                DB::raw('COALESCE(products.barcode, "") as barcode'),
                DB::raw('COALESCE(products.sku, "") as sku'),
                DB::raw('COALESCE(products.unit, purchase_items.unit_label) as satuan_dasar'),
                DB::raw('COALESCE(products.stock, 0) as sisa_stok_toko'),
                DB::raw('SUM(purchase_items.qty * COALESCE(purchase_items.unit_conversion, 1)) as total_base_qty'),
                DB::raw('SUM(purchase_items.subtotal) as total_nominal'),
                DB::raw('COUNT(DISTINCT purchase_items.purchase_id) as jumlah_faktur'),
                DB::raw('MAX(purchases.purchase_date) as tgl_faktur_terakhir')
            )
            ->groupBy('purchase_items.product_id', 'nama_produk', 'barcode', 'sku', 'satuan_dasar', 'sisa_stok_toko')
            ->orderByDesc('total_nominal')
            ->paginate(20, ['*'], 'rekap_page')
            ->withQueryString();

        // Rincian satuan dan daftar faktur untuk item pada halaman aktif
        $activeProductIds = collect($rekapProduk->items())->pluck('product_id')->filter()->unique();
        $rincianSatuanMap = [];
        $riwayatFakturMap = [];

        if ($activeProductIds->isNotEmpty()) {
            $detailItemsQuery = DB::table('purchase_items')
                ->join('purchases', 'purchases.id', '=', 'purchase_items.purchase_id')
                ->leftJoin('suppliers', 'suppliers.id', '=', 'purchases.supplier_id')
                ->whereIn('purchase_items.product_id', $activeProductIds);

            if ($rekapFrom && $rekapTo) {
                $detailItemsQuery->whereDate('purchases.purchase_date', '>=', $rekapFrom)
                                 ->whereDate('purchases.purchase_date', '<=', $rekapTo);
            } elseif ($rekapFrom) {
                $detailItemsQuery->whereDate('purchases.purchase_date', '>=', $rekapFrom);
            } elseif ($rekapTo) {
                $detailItemsQuery->whereDate('purchases.purchase_date', '<=', $rekapTo);
            }

            if ($request->filled('supplier_id')) {
                $detailItemsQuery->where('purchases.supplier_id', $request->supplier_id);
            }

            $rawDetails = $detailItemsQuery
                ->select(
                    'purchase_items.product_id',
                    'purchase_items.unit_label',
                    'purchase_items.unit_conversion',
                    'purchases.id as purchase_id',
                    'purchases.purchase_no',
                    'purchases.supplier_invoice_no',
                    'purchases.purchase_date',
                    'suppliers.name as supplier_name',
                    'purchase_items.qty',
                    'purchase_items.price',
                    'purchase_items.subtotal'
                )
                ->orderByDesc('purchases.purchase_date')
                ->get();

            foreach ($rawDetails->groupBy('product_id') as $pId => $items) {
                $unitsGroup = [];
                foreach ($items->groupBy('unit_label') as $uLabel => $uItems) {
                    $unitsGroup[] = [
                        'unit_label' => $uLabel,
                        'total_qty' => (float) $uItems->sum('qty'),
                        'conversion' => (float) ($uItems->first()->unit_conversion ?? 1),
                        'total_subtotal' => (float) $uItems->sum('subtotal'),
                    ];
                }
                $rincianSatuanMap[$pId] = $unitsGroup;

                $riwayatFakturMap[$pId] = $items->map(fn ($it) => [
                    'purchase_id' => $it->purchase_id,
                    'purchase_no' => $it->purchase_no,
                    'supplier_invoice_no' => $it->supplier_invoice_no,
                    'purchase_date' => $it->purchase_date,
                    'supplier_name' => $it->supplier_name ?: 'Umum / Tanpa Supplier',
                    'qty' => (float) $it->qty,
                    'unit_label' => $it->unit_label,
                    'price' => (float) $it->price,
                    'subtotal' => (float) $it->subtotal,
                ])->values()->all();
            }
        }

        $suppliers = Supplier::orderBy('name')->get();
        $products = Product::with('units.unit')->where('is_active', true)->where('type', 'barang')
            ->orderBy('name')->get()
            ->map(fn (Product $p) => [
                'id' => $p->id,
                'name' => $p->name,
                'sku' => $p->sku,
                'barcode' => $p->barcode,
                'unit' => $p->unit,
                'stock' => (float) ($p->stock ?? 0),
                'cost_price' => (float) ($p->cost_price ?? 0),
                'sell_price' => (float) ($p->sell_price ?? 0),
                'units' => $p->units->map(fn ($pu) => [
                    'id' => $pu->id,
                    'name' => $pu->unit->name,
                    'conversion' => (float) $pu->conversion,
                    'barcode' => $pu->barcode,
                    'cost_price' => $pu->cost_price !== null ? (float) $pu->cost_price : (float) (($p->cost_price ?? 0) * $pu->conversion),
                    'price' => $pu->price !== null ? (float) $pu->price : (float) (($p->sell_price ?? 0) * $pu->conversion),
                ])->values()->all(),
            ])->values();

        return view('transaksi.pembelian.index', compact(
            'purchases', 'ringkasan', 'suppliers', 'products',
            'rekapProduk', 'rekapRingkasan', 'rincianSatuanMap', 'riwayatFakturMap',
            'rekapPeriode', 'rekapFrom', 'rekapTo'
        ));
    }

    /**
     * Endpoint langsung untuk membuka tab Rekap Barang Dibeli.
     */
    public function rekapProduk(Request $request)
    {
        return redirect()->route('pembelian.index', array_merge(['tab' => 'rekap_produk'], $request->all()));
    }

    public function store(Request $request, ProductCatalog $catalog)
    {
        $data = $request->validate([
            'supplier_id' => ['nullable', 'exists:suppliers,id'],
            'supplier_invoice_no' => ['nullable', 'string', 'max:100'],
            // TIDAK BOLEH TANGGAL DEPAN, dan ini bukan sekadar kerapian.
            //
            // Stok bertambah SEKARANG apa pun tanggal notanya, tapi hutangnya baru ikut
            // dihitung Neraca setelah tanggal itu tiba (Akuntansi::posisiPada menyaring
            // purchase_date <= tanggal). Jadi satu salah ketik tahun membuat persediaan naik
            // tanpa pasangan di sisi kewajiban - neraca timpang persis sebesar nota itu, dan
            // pemilik toko tidak akan punya cara menebak penyebabnya.
            'purchase_date' => ['required', 'date', 'before_or_equal:today'],
            'other_cost' => ['nullable', 'numeric', 'min:0'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['required', 'exists:products,id'],
            'items.*.qty' => ['required', 'numeric', 'min:0.0001'],
            'items.*.unit_type' => ['nullable', 'string'],
            'items.*.price' => ['required', 'numeric', 'min:0'],
            'items.*.sell_price' => ['nullable', 'numeric', 'min:0'],
            'other_unit_prices' => ['nullable', 'array'],
            'other_unit_prices.*.product_id' => ['required', 'exists:products,id'],
            'other_unit_prices.*.unit_type' => ['required', 'string'],
            'other_unit_prices.*.sell_price' => ['nullable', 'numeric', 'min:0'],
            'other_unit_prices.*.cost_price' => ['nullable', 'numeric', 'min:0'],
            'bayar' => ['required', 'in:tunai,hutang'],
            'paid_amount' => ['nullable', 'numeric', 'min:0'],
            'due_date' => ['nullable', 'date'],
            'note' => ['nullable', 'string'],
        ]);

        $purchase = DB::transaction(function () use ($data, $request, $catalog) {
            $biayaLain = (float) ($data['other_cost'] ?? 0);

            // Baris dihitung dulu supaya subtotal nota diketahui sebelum biaya kirim dibagi.
            $baris = [];
            $subtotal = 0.0;

            $loadedProducts = [];
            foreach ($data['items'] as $item) {
                $pid = (int) $item['product_id'];
                if (!isset($loadedProducts[$pid])) {
                    $loadedProducts[$pid] = Product::lockForUpdate()->findOrFail($pid);
                }
                $product = $loadedProducts[$pid];
                ['conversion' => $konversi, 'label' => $label] = $this->satuanPembelian($product, $item['unit_type'] ?? 'base');

                $nilai = Angka::bulat((float) $item['qty'] * (float) $item['price']);
                $subtotal = Angka::bulat($subtotal + $nilai);

                $baris[] = [
                    'product' => $product,
                    'qty' => (float) $item['qty'],
                    'konversi' => $konversi,
                    'label' => $label,
                    'price' => (float) $item['price'],
                    'sell_price' => isset($item['sell_price']) && $item['sell_price'] !== '' ? (float) $item['sell_price'] : null,
                    'unit_type' => $item['unit_type'] ?? 'base',
                    'subtotal' => $nilai,
                ];
            }

            $total = Angka::bulat($subtotal + $biayaLain);
            $tunai = $data['bayar'] === 'tunai';
            $dibayar = $tunai ? $total : Angka::bulat($data['paid_amount'] ?? 0);

            if ($dibayar > $total) {
                abort(422, 'Jumlah bayar melebihi total pembelian.');
            }

            $purchase = Purchase::create([
                'purchase_no' => Purchase::generateNo(),
                'supplier_id' => $data['supplier_id'] ?? null,
                'supplier_invoice_no' => $data['supplier_invoice_no'] ?? null,
                'purchase_date' => $data['purchase_date'],
                'subtotal' => $subtotal,
                'other_cost' => $biayaLain,
                'total' => $total,
                'paid_amount' => $dibayar,
                'sisa_hutang' => Angka::bulat($total - $dibayar),
                'due_date' => $tunai ? null : ($data['due_date'] ?? null),
                'note' => $data['note'] ?? null,
                'user_id' => $request->user()->id,
            ]);

            foreach ($baris as $b) {
                PurchaseItem::create([
                    'purchase_id' => $purchase->id,
                    'product_id' => $b['product']->id,
                    'product_name' => $b['product']->name,
                    'qty' => $b['qty'],
                    'unit_label' => $b['label'],
                    'unit_conversion' => $b['konversi'],
                    'price' => $b['price'],
                    'subtotal' => $b['subtotal'],
                ]);

                $qtySatuanDasar = Angka::keSatuanDasar($b['qty'], $b['konversi']);
                $stokSesudah = $b['product']->ubahStok($qtySatuanDasar);

                StockMovement::create([
                    'product_id' => $b['product']->id,
                    'type' => 'in',
                    'qty' => $qtySatuanDasar,
                    'stock_after' => $stokSesudah,
                    'note' => 'Pembelian ' . $purchase->purchase_no,
                    'user_id' => $request->user()->id,
                ]);

                $this->perbaruiHargaModal($b, $subtotal, $biayaLain, $qtySatuanDasar);

                if ($b['sell_price'] !== null && $b['sell_price'] > 0) {
                    if ($b['unit_type'] === 'base' || $b['unit_type'] === '') {
                        $b['product']->sell_price = $b['sell_price'];
                        $b['product']->save();
                    } elseif (str_starts_with($b['unit_type'], 'unit_')) {
                        $unitId = (int) substr($b['unit_type'], 5);
                        $productUnit = $b['product']->units()->find($unitId);
                        if ($productUnit) {
                            $productUnit->price = $b['sell_price'];
                            if ($b['price'] > 0) {
                                $productUnit->cost_price = $b['price'];
                            }
                            $productUnit->save();
                        }
                    }
                } elseif (str_starts_with($b['unit_type'], 'unit_') && $b['price'] > 0) {
                    $unitId = (int) substr($b['unit_type'], 5);
                    $productUnit = $b['product']->units()->find($unitId);
                    if ($productUnit) {
                        $productUnit->cost_price = $b['price'];
                        $productUnit->save();
                    }
                }
            }

            if (!empty($data['other_unit_prices'])) {
                foreach ($data['other_unit_prices'] as $oup) {
                    $sellPrice = isset($oup['sell_price']) && $oup['sell_price'] !== '' ? (float) $oup['sell_price'] : null;
                    if ($sellPrice === null || $sellPrice <= 0) continue;

                    $p = $loadedProducts[$oup['product_id']] ?? Product::find($oup['product_id']);
                    if (!$p) continue;

                    if ($oup['unit_type'] === 'base' || $oup['unit_type'] === '') {
                        $p->sell_price = $sellPrice;
                        $p->save();
                    } elseif (str_starts_with($oup['unit_type'], 'unit_')) {
                        $uId = (int) substr($oup['unit_type'], 5);
                        $pu = $p->units()->find($uId);
                        if ($pu) {
                            $pu->price = $sellPrice;
                            if (isset($oup['cost_price']) && (float) $oup['cost_price'] > 0) {
                                $pu->cost_price = (float) $oup['cost_price'];
                            }
                            $pu->save();
                        }
                    }
                }
            }

            if ($dibayar > 0) {
                $this->catatKasKeluar($purchase, $dibayar, $request->user()->id, 'Pembelian ' . $purchase->purchase_no);
            }

            return $purchase;
        });

        // Harga modal berubah, jadi katalog kasir harus dibangun ulang.
        $catalog->flush();

        return back()
            ->with('success', "Pembelian {$purchase->purchase_no} tersimpan. Stok sudah bertambah.")
            ->with('last_purchase_id', $purchase->id)
            ->with('last_purchase_no', $purchase->purchase_no);
    }

    /**
     * Mencatat pembayaran hutang, sebagian atau seluruhnya.
     */
    public function bayar(Request $request, Purchase $purchase)
    {
        $data = $request->validate([
            'amount' => ['required', 'numeric', 'min:0.01'],
            'paid_at' => ['required', 'date'],
            'note' => ['nullable', 'string'],
        ]);

        DB::transaction(function () use ($data, $request, $purchase) {
            // Dikunci dan dibaca ULANG di dalam transaksi. Tanpa ini, dua klik "Bayar" yang
            // hampir bersamaan bisa sama-sama lolos pemeriksaan sisa hutang dan mencatat
            // pembayaran dua kali untuk nota yang sama.
            $nota = Purchase::lockForUpdate()->find($purchase->id);
            if (! $nota) {
                return;
            }

            $jumlah = Angka::bulat($data['amount']);

            if (! Angka::cukup($jumlah, $nota->sisa_hutang)) {
                abort(422, 'Jumlah bayar melebihi sisa hutang (Rp ' . number_format((float) $nota->sisa_hutang, 0, ',', '.') . ').');
            }

            PurchasePayment::create([
                'purchase_id' => $nota->id,
                'amount' => $jumlah,
                'paid_at' => $data['paid_at'],
                'note' => $data['note'] ?? null,
                'user_id' => $request->user()->id,
            ]);

            $nota->paid_amount = Angka::bulat($nota->paid_amount + $jumlah);
            $nota->sisa_hutang = Angka::bulat($nota->total - $nota->paid_amount);
            $nota->save();

            $this->catatKasKeluar($nota, $jumlah, $request->user()->id, 'Bayar hutang ' . $nota->purchase_no);
        });

        return back()->with('success', 'Pembayaran tersimpan.');
    }

    /**
     * Membatalkan pembelian: stok dikembalikan, dan seluruh jejak uangnya ikut dibuang.
     */
    public function destroy(Request $request, Purchase $purchase, ProductCatalog $catalog)
    {
        $nomor = $purchase->purchase_no;

        DB::transaction(function () use ($purchase, $request) {
            $nota = Purchase::lockForUpdate()->with('items')->find($purchase->id);
            if (! $nota) {
                return;
            }

            foreach ($nota->items as $item) {
                if (! $item->product_id) {
                    continue;
                }

                $product = Product::lockForUpdate()->find($item->product_id);
                if (! $product || $product->isJasa()) {
                    continue;
                }

                $qtySatuanDasar = Angka::keSatuanDasar($item->qty, $item->unit_conversion);

                if (! Angka::cukup($qtySatuanDasar, $product->stock)) {
                    abort(422, "Stok {$product->name} sudah terjual sebagian, jadi pembelian ini tidak bisa dibatalkan. Buat penyesuaian stok kalau memang salah catat.");
                }

                $stokSesudah = $product->ubahStok(-$qtySatuanDasar);

                StockMovement::create([
                    'product_id' => $product->id,
                    'type' => 'out',
                    'qty' => -$qtySatuanDasar,
                    'stock_after' => $stokSesudah,
                    'note' => 'Pembatalan pembelian ' . $nota->purchase_no,
                    'user_id' => $request->user()->id,
                ]);
            }

            // Uang yang sudah dibayar dikembalikan ke kas, supaya saldo kas tetap benar.
            $totalDibayar = Angka::bulat($nota->paid_amount);
            if ($totalDibayar > 0) {
                CashTransaction::create([
                    'type' => 'in',
                    'category' => 'pembelian',
                    'amount' => $totalDibayar,
                    'note' => 'Pembatalan pembelian ' . $nota->purchase_no,
                    'user_id' => $request->user()->id,
                ]);
            }

            $nota->delete();
        });

        $catalog->flush();

        return back()->with('success', "Pembelian {$nomor} dibatalkan, stok dan kas sudah dikembalikan.");
    }

    /**
     * Satuan yang dipakai membeli: satuan dasar produk, atau salah satu satuan tambahannya.
     * Toko biasanya kulakan per Dus walau menjual per Pcs.
     */
    private function satuanPembelian(Product $product, string $unitType): array
    {
        if ($unitType === 'base' || $unitType === '') {
            return ['conversion' => 1.0, 'label' => $product->unit];
        }

        $productUnit = $product->units->firstWhere('id', (int) str_replace('unit_', '', $unitType));

        if (! $productUnit) {
            abort(422, "Satuan pembelian untuk {$product->name} tidak ditemukan atau sudah dihapus.");
        }

        return ['conversion' => (float) $productUnit->conversion, 'label' => $productUnit->unit->name];
    }

    /**
     * Memperbarui harga modal produk dari harga beli nota ini.
     *
     * Biaya kirim dibagi ke tiap barang SEBANDING NILAINYA, bukan rata per baris: mengirim
     * satu dus barang mahal dan satu dus barang murah memang menghabiskan ongkos yang sama,
     * tapi membebankan ongkir yang sama ke keduanya membuat margin barang murah terlihat
     * jauh lebih buruk daripada kenyataannya.
     */
    private function perbaruiHargaModal(array $baris, float $subtotalNota, float $biayaLain, float $qtySatuanDasar): void
    {
        if ($qtySatuanDasar <= 0) {
            return;
        }

        $porsiBiaya = $subtotalNota > 0
            ? Angka::bulat($biayaLain * ($baris['subtotal'] / $subtotalNota))
            : 0.0;

        $modalPerSatuanDasar = round(($baris['subtotal'] + $porsiBiaya) / $qtySatuanDasar, 2);

        $baris['product']->cost_price = $modalPerSatuanDasar;
        $baris['product']->save();
    }

    /**
     * Kas keluar untuk pembelian barang.
     *
     * Kategorinya sengaja `pembelian`, yang TIDAK termasuk beban di laporan laba rugi.
     * Uangnya belum jadi biaya - ia berubah wujud menjadi persediaan di rak, dan baru
     * menjadi beban saat barangnya terjual, dihitung di sana sebagai HPP.
     */
    private function catatKasKeluar(Purchase $purchase, float $jumlah, int $userId, string $catatan): void
    {
        CashTransaction::create([
            'type' => 'out',
            'category' => 'pembelian',
            'amount' => $jumlah,
            'note' => $catatan . ($purchase->supplier ? ' - ' . $purchase->supplier->name : ''),
            'user_id' => $userId,
        ]);
    }

    /**
     * Menampilkan lembar cetak faktur pembelian / bukti barang masuk (GRN).
     * Siap dicetak format standar kertas A4 ataupun struk ringkas.
     */
    public function cetak(Purchase $purchase)
    {
        $purchase->load(['supplier', 'items.product', 'payments.user', 'user']);
        $storeProfile = Setting::get('store_profile', [
            'name' => config('app.name', 'JPOS'),
            'address' => '',
            'phone' => '',
        ]);
        return view('transaksi.pembelian.cetak', compact('purchase', 'storeProfile'));
    }
}
